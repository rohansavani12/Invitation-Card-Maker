package com.invitationcardmaker.edigitalcard;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Base64;

import androidx.multidex.MultiDexApplication;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.invitationcardmaker.edigitalcard.main.AllConstants;
import com.invitationcardmaker.edigitalcard.pojoClass.Advertise;

import com.invitationcardmaker.edigitalcard.R;

//import com.onesignal.OneSignal;

/* loaded from: classes2.dex */
public class InvitationApplication extends MultiDexApplication {
    public static String FULL_URL_MAIN = null;
    public static Context Mcontext = null;
    private static final String ONESIGNAL_APP_ID = "3eeb15d1-afdc-40ae-b0fd-349acf868aed";
    public static final String TAG = "InvitationApplication";
    public static final String TAG1 = "AppController";
    public static String admobBanner = "admob_banner";
    public static String admobInterstial = "admob_inter";
    public static String admobInterstial1 = "admob_inter1";
    public static String admobNative = "admob_native";
    public static String admob_appopen = "admob_appopen";
    public static String admob_quizicon = "admob_quizicon";
    public static String admobbannerNative = "admob_banner_native";
    public static Advertise advertise = null;
    public static String google_banner = null;
    public static String google_interstitial = null;
    public static String google_native = null;
    public static String google_openapp = null;
    public static String google_quizicon = null;
    public static String google_rewarded_interstitial = null;
    private static InvitationApplication instance = null;
    public static boolean isDataComplete = false;
    public static String isSplash = "isSplash";
    private static InvitationApplication mInstance = null;
    public static int onAddclick = 0;
    public static String onclick = null;
    public static String prefName = "myPref";
    public static SharedPreferences preferences = null;
    public static String qurekalink = "qurekalink";
    public static SharedPreferences sharedPreferences;
    private String FULL_URL_MAIN_BACKUP = "";
    public SharedPreferences.Editor editor;
    private RequestQueue mRequestQueue;
    private DatabaseReference reference;




    public static FirebaseApp firebaseApp;


    public static synchronized InvitationApplication getInstance() {
        synchronized (InvitationApplication.class) {
            InvitationApplication invitationApplication = mInstance;
            if (invitationApplication != null) {
                return invitationApplication;
            }
            InvitationApplication invitationApplication2 = new InvitationApplication();
            mInstance = invitationApplication2;
            return invitationApplication2;
        }
    }

    public RequestQueue getRequestQueue() {
        if (this.mRequestQueue == null) {
            this.mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }
        return this.mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> request, String str) {
        if (TextUtils.isEmpty(str)) {
            str = TAG;
        }
        request.setTag(str);
        getRequestQueue().add(request);
    }

    public <T> void addToRequestQueue(Request<T> request) {
        request.setTag(TAG);
        getRequestQueue().add(request);
    }

    public void cancelPendingRequests(Object obj) {
        RequestQueue requestQueue = this.mRequestQueue;
        if (requestQueue != null) {
            requestQueue.cancelAll(obj);
        }
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        mInstance = this;
//        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
//        OneSignal.initWithContext(this);
//        OneSignal.setAppId(ONESIGNAL_APP_ID);
        SharedPreferences sharedPreferences2 = getSharedPreferences(prefName, 0);
        sharedPreferences = sharedPreferences2;
        preferences = sharedPreferences2;
        this.editor = sharedPreferences2.edit();

        FirebaseOptions firebaseOptions = new FirebaseOptions.Builder()
                .setProjectId("invitation-maker-fa4d5")
                .setGcmSenderId("194296675608")
                .setStorageBucket("invitation-maker-fa4d5.appspot.com")
                .setApiKey("AIzaSyDdk436c6bad9mb485urizXURmTHkTKYj4")
                .setApplicationId("1:194296675608:android:f9ceca4dc70655a371b26d")
                .setDatabaseUrl("BuildConfig.AD_DATABASE_URL")
                .build();

        firebaseApp = FirebaseApp.initializeApp(getApplicationContext(), firebaseOptions, String.valueOf(R.string.app_name));


//        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("invitation_card");
//        this.reference = reference;


//        reference.addListenerForSingleValueEvent(new ValueEventListener() { // from class: com.invitationcardmaker.edigitalcard.InvitationApplication.1
//            @Override // com.google.firebase.database.ValueEventListener
//            public void onCancelled(DatabaseError databaseError) {
//            }
//
//            @Override // com.google.firebase.database.ValueEventListener
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                InvitationApplication.google_banner = dataSnapshot.child("google_banner").getValue().toString();
//                Log.d("google_banner", "onDataChange: " + InvitationApplication.google_banner);
//                InvitationApplication.google_interstitial = dataSnapshot.child("google_interstitial").getValue().toString();
//                InvitationApplication.google_native = dataSnapshot.child("google_native").getValue().toString();
//                InvitationApplication.google_openapp = dataSnapshot.child("google_appopen").getValue().toString();
//                InvitationApplication.google_rewarded_interstitial = dataSnapshot.child("google_rewarded_interstitial").getValue().toString();
//                InvitationApplication.onclick = dataSnapshot.child("onclick").getValue().toString();
//                Log.d("google_banner1", "onDataChange: " + InvitationApplication.google_interstitial);
//                InvitationApplication.isDataComplete = true;
//            }
//        });
        FULL_URL_MAIN = new String(Base64.decode("aHR0cDovL3RocmVlbWFydGlhbnMuaW4v", 0));
        AllConstants.BASE_URL_POSTER = FULL_URL_MAIN + "invitationmaker/API/V1/";
        AllConstants.BASE_URL_POSTER_BG = FULL_URL_MAIN + "invitationmaker/API/V1/";
        AllConstants.BASE_URL_STICKER = FULL_URL_MAIN + "invitationmaker/";
        AllConstants.BASE_URL_BG = FULL_URL_MAIN + "posterbackgound/";
        AllConstants.BASE_URL = FULL_URL_MAIN + "poster1/Resources/Poster.php";
        AllConstants.stickerURL = FULL_URL_MAIN + "poster1/Resources/";
        AllConstants.fURL = FULL_URL_MAIN + "poster1/Resources/Fonts/";
        AllConstants.bgURL = FULL_URL_MAIN + "poster1/Resources/Background/";
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
//        AppOpenManager appOpenManager2 = new AppOpenManager(this);
//        appOpenManager = appOpenManager2;
//        appOpenManager2.onStart();
    }
}
