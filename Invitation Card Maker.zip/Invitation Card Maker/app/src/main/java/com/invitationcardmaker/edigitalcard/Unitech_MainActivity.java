package com.invitationcardmaker.edigitalcard;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;

/* loaded from: classes2.dex */
public class Unitech_MainActivity extends AppCompatActivity {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.unitech_activity_main);
    }
}
