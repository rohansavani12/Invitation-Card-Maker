package com.invitationcardmaker.edigitalcard.Unitech_SplashExit.Common;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Glob {

    public static String App_Name = "Digital Invitation Card";
    public static String App_Link = "https://play.google.com/store/apps/details?id=com.invitationcardmaker.edigitalcard&hl=en";
    public static String privacy_link = "https://newsurvivorprivacypolicy.blogspot.com/2022/12/privacy-policy-for-apps.html";


    public static Boolean CheckNet(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}
