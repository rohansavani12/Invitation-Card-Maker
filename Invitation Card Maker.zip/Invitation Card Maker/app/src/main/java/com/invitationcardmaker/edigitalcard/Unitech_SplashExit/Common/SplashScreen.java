package com.invitationcardmaker.edigitalcard.Unitech_SplashExit.Common;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_SplashExit.Unitech_SecondActivity;


public class SplashScreen extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unitech_activity_splash_screen);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!getSharedPreferences(getPackageName(), MODE_PRIVATE).getBoolean("apppermi", false)) {
                    startActivity(new Intent(SplashScreen.this, Unitech_AppPermissionActivity.class));
                } else {
                    startActivity(new Intent(SplashScreen.this, Unitech_SecondActivity.class));
                }
            }
        }, 3000);
    }
}