package com.invitationcardmaker.edigitalcard.Unitech_SplashExit;

import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;


public class Unitech_BackActivity extends AppCompatActivity {

    @Override
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back);





        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        ((ImageView) findViewById(R.id.yes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                startActivity(new Intent(Unitech_BackActivity.this, Unitech_ThankYouActivity.class));


            }
        });

        ((ImageView) findViewById(R.id.no)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Unitech_BackActivity.this, Unitech_SecondActivity.class));
            }
        });

    }

    @Override
    public void onBackPressed() {
    }



}
