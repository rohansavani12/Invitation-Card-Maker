package com.invitationcardmaker.edigitalcard.Unitech_SplashExit;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;


public class Unitech_FirstActivity extends AppCompatActivity {

    ImageView getstart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        getstart = findViewById(R.id.start);
        getstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Unitech_FirstActivity.this, Unitech_SecondActivity.class));


            }
        });
    }
    @Override
    public void onBackPressed() {
        finish();
        finishAffinity();
    }
}