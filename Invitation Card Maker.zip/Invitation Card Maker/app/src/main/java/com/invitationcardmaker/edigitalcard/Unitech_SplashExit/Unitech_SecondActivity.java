package com.invitationcardmaker.edigitalcard.Unitech_SplashExit;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_SplashExit.Common.Glob;
import com.invitationcardmaker.edigitalcard.Unitech_activity.MainActivity;


public class Unitech_SecondActivity extends AppCompatActivity {
    ImageView main_start;
    public ImageView poppummenu;
    ImageView s_rate, s_privacy, s_share;
    private static final int MY_REQUEST_CODE = 1;
    private static final int MY_REQUEST_CODE1 = 3;
    private static final int MY_REQUEST_CODE2 = 4;
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 2000;
    Button Start;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unitech_activity_second);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        main_start = findViewById(R.id.start);
        s_rate = findViewById(R.id.s_rate);
        s_privacy = findViewById(R.id.s_privacy);
        s_share = findViewById(R.id.s_share);
        main_start.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                startActivity(new Intent(Unitech_SecondActivity.this, MainActivity.class));
            }
        });

        s_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                startActivity(new Intent(Unitech_SecondActivity.this, Unitech_WebActivity.class));

            }
        });

        s_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoStore();
            }
        });

        s_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share();
            }
        });


    }

    public void gotoStore() {
        Uri uri = Uri.parse(Glob.App_Link);
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        myAppLinkToMarket.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        try {
            startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(Unitech_SecondActivity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
        }
    }

    public void share() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.TEXT", Glob.App_Name + " Created By :" + Glob.App_Link);
        startActivity(Intent.createChooser(intent, "Share Image using"));
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(Unitech_SecondActivity.this, Unitech_BackActivity.class));


    }

}