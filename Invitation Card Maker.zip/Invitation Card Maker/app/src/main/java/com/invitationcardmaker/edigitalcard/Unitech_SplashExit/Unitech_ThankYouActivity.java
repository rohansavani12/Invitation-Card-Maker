package com.invitationcardmaker.edigitalcard.Unitech_SplashExit;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;


public class Unitech_ThankYouActivity extends AppCompatActivity {

    private ImageView exitapp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unitech_activity_thank_you_main);


        exitapp = findViewById(R.id.exitapp);
        exitapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                finishAffinity();
            }
        });
    }


    @Override
    public void onBackPressed() {

    }
}