package com.invitationcardmaker.edigitalcard.Unitech_activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import cn.pedant.SweetAlert.SweetAlertDialog;
import com.invitationcardmaker.edigitalcard.R;

import com.google.android.material.button.MaterialButton;

import com.invitationcardmaker.edigitalcard.InvitationApplication;
import com.invitationcardmaker.edigitalcard.Unitech_SplashExit.Unitech_SecondActivity;
import com.invitationcardmaker.edigitalcard.main.AllConstants;
import com.invitationcardmaker.edigitalcard.main.BGImageActivity;
import com.invitationcardmaker.edigitalcard.main.InvitationCatActivity;
import com.invitationcardmaker.edigitalcard.main.WorkCardActivity;
import com.invitationcardmaker.edigitalcard.main.WorkDesignActivity;
import com.invitationcardmaker.edigitalcard.network.NetworkConnectivityReceiver;
import com.invitationcardmaker.edigitalcard.pojoClass.StickerWork;
import com.invitationcardmaker.edigitalcard.utils.Configure;
import com.invitationcardmaker.edigitalcard.utils.PreferenceClass;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Unitech_BaseActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    public static ArrayList<StickerWork> allStickerArrayList;
    public static float ratio;
    public static int width;
    private RelativeLayout ads_relative;
    private ImageView amin_drawable;
    AnimationDrawable animation;
    private SharedPreferences appPreferences;
    private LinearLayout btnLayoutMore;
    private MaterialButton btnLayoutRate;
    private LinearLayout btnLayoutShare;
    public SharedPreferences.Editor editor;
    FrameLayout frameBanner;
    int i1;
    boolean isAppInstalled = false;
    boolean isRegister = false;
    private RelativeLayout layPhotos;
    private RelativeLayout layPoster;
    private RelativeLayout layTemplate;
    public boolean lay_photos = false;
    public boolean lay_poster = false;
    public boolean lay_templates = false;
    private MaterialButton llMoreApp;
    private PreferenceClass preferenceClass;
    private SharedPreferences preferences;
    public SharedPreferences prefs;
    ProgressDialog progress;
    private TextView txtMoreApp;
    private TextView txtRateApp;

    public void createShortCut() {
    }

    private void setAdsVisible() {
        if (!NetworkConnectivityReceiver.isConnected()) {
            this.ads_relative.setVisibility(8);
            this.amin_drawable.setVisibility(0);
            this.amin_drawable.setImageResource(R.drawable.anim);
            AnimationDrawable animationDrawable = (AnimationDrawable) this.amin_drawable.getDrawable();
            this.animation = animationDrawable;
            animationDrawable.start();
        } else if (!this.prefs.getBoolean("isAdsDisabled", false)) {
            this.ads_relative.setVisibility(8);
            this.amin_drawable.setVisibility(0);
            this.amin_drawable.setImageResource(R.drawable.anim);
            AnimationDrawable animationDrawable2 = (AnimationDrawable) this.amin_drawable.getDrawable();
            this.animation = animationDrawable2;
            animationDrawable2.start();
            if (InvitationApplication.advertise != null) {
                InvitationApplication.advertise.getFlag().equalsIgnoreCase("1");
            }
        } else {
            this.ads_relative.setVisibility(8);
            this.amin_drawable.setVisibility(0);
            this.amin_drawable.setImageResource(R.drawable.anim);
            AnimationDrawable animationDrawable3 = (AnimationDrawable) this.amin_drawable.getDrawable();
            this.animation = animationDrawable3;
            animationDrawable3.start();
        }
    }


    @SuppressLint("ResourceType")
    @Override
    // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, com.invitationcardmaker.edigitalcard.activity.BaseActivity
    public void onCreate(Bundle bundle) {
        getWindow().setFlags(1024, 1024);
        super.onCreate(bundle);
        setContentView(R.layout.unitech_activity_main);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.layoutBannerAd);
        this.frameBanner = frameLayout;
        PreferenceClass preferenceClass2 = new PreferenceClass(this);
        this.preferenceClass = preferenceClass2;
        SharedPreferences prefernce = preferenceClass2.getPrefernce();
        this.preferences = prefernce;
        this.editor = prefernce.edit();
        this.prefs = this.preferenceClass.getPrefernce();
        this.amin_drawable = (ImageView) findViewById(R.id.images);
//        setAdsVisible();
        setMyFontNormal((ViewGroup) findViewById(16908290));
        findViews();
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.appPreferences = defaultSharedPreferences;
        boolean z = defaultSharedPreferences.getBoolean("isAppInstalled", false);
        this.isAppInstalled = z;
        if (!z) {
            createShortCut();
            SharedPreferences.Editor edit = this.appPreferences.edit();
            edit.putBoolean("isAppInstalled", true);
            edit.commit();
        }
    }

    public void makeStickerDir() {
        this.preferenceClass = new PreferenceClass(this);
        File file = new File(Configure.GetFileDir(this).getPath() + "/.Invitation Stickers/sticker");
        if (!file.exists()) {
            file.mkdirs();
        }
        this.preferenceClass.putString(AllConstants.sdcardPath, file.getPath());
        Log.e(TAG, "onCreate: " + AllConstants.sdcardPath);
    }

    private void findViews() {
        this.layPoster = (RelativeLayout) findViewById(R.id.lay_poster);
        this.layTemplate = (RelativeLayout) findViewById(R.id.lay_template);
        this.layPhotos = (RelativeLayout) findViewById(R.id.lay_photos);
        this.btnLayoutMore = (LinearLayout) findViewById(R.id.btnLayoutMore);
        this.layPoster.setOnClickListener(this);
        this.layTemplate.setOnClickListener(this);
        this.layPhotos.setOnClickListener(this);
        this.btnLayoutMore.setOnClickListener(this);
    }

    @Override // androidx.fragment.app.FragmentActivity
    public void onResume() {
        super.onResume();
    }

    public void onClick(View view) {
        requestStoragePermissionOnclick(view.getId());
    }

    private void requestStoragePermissionOnclick(final int i) {
        Dexter.withActivity(this).withPermissions("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA").withListener(new MultiplePermissionsListener() {
            /* class com.invitationcardmaker.edigitalcard.activity.MainActivity.AnonymousClass3 */

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                if (multiplePermissionsReport.areAllPermissionsGranted()) {
                    MainActivity.this.makeStickerDir();
                    if (NetworkConnectivityReceiver.isConnected()) {
                        MainActivity.this.getSticker();
                        switch (i) {
                            case R.id.btnLayoutMore:
                                MainActivity.this.lay_poster = false;
                                MainActivity.this.lay_templates = false;
                                MainActivity.this.lay_photos = true;
                                MainActivity.this.startActivity(new Intent(MainActivity.this, WorkDesignActivity.class));
                                return;
                            case R.id.lay_photos:
                                MainActivity.this.startActivity(new Intent(MainActivity.this, WorkCardActivity.class));
                                return;
                            case R.id.lay_poster:
                                MainActivity.this.lay_poster = true;
                                MainActivity.this.lay_templates = false;
                                MainActivity.this.lay_photos = false;
                                MainActivity.this.startActivity(new Intent(MainActivity.this, BGImageActivity.class));
                                return;
                            case R.id.lay_template:
                                if (NetworkConnectivityReceiver.isConnected()) {
                                    MainActivity.this.lay_poster = false;
                                    MainActivity.this.lay_templates = true;
                                    MainActivity.this.lay_photos = false;
                                    MainActivity.this.startActivity(new Intent(MainActivity.this, InvitationCatActivity.class));
                                } else {
                                    MainActivity.this.networkError();
                                }


                                return;
                            default:
                                return;
                        }
                    } else {
                        MainActivity.this.networkError();
                    }
                } else if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    MainActivity.this.showSettingsDialog();
                }
            }

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() {
            /* class com.invitationcardmaker.edigitalcard.activity.MainActivity.AnonymousClass2 */

            @Override // com.karumi.dexter.listener.PermissionRequestErrorListener
            public void onError(DexterError dexterError) {
                Toast.makeText(MainActivity.this.getApplicationContext(), "Error occurred! ", 0).show();
            }
        }).onSameThread().check();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @SuppressLint("MissingPermission")
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.activity.MainActivity.AnonymousClass7 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                MainActivity.this.openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.activity.MainActivity.AnonymousClass8 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void openSettings() {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivityForResult(intent, 101);
    }

    @Override // androidx.activity.ComponentActivity
    public void onBackPressed() {
        startActivity(new Intent(MainActivity.this, Unitech_SecondActivity.class));
    }

    public void networkError() {
        new SweetAlertDialog(this, 3).setTitleText("No Internet connected?").setContentText("make sure your internet connection is working.").setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
            /* class com.invitationcardmaker.edigitalcard.activity.MainActivity.AnonymousClass9 */

            @Override // cn.pedant.SweetAlert.SweetAlertDialog.OnSweetClickListener
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                sweetAlertDialog.dismissWithAnimation();
            }
        }).show();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onDestroy() {
        super.onDestroy();
    }
}