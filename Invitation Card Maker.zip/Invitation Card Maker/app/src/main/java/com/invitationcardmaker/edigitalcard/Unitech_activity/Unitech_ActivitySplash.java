package com.invitationcardmaker.edigitalcard.Unitech_activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;

import com.invitationcardmaker.edigitalcard.R;

public class Unitech_ActivitySplash extends AppCompatActivity {
    int SPLASH_TIME = 1000;
    ProgressBar splashProgress;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.unitech_activity_splash);
        this.splashProgress = (ProgressBar) findViewById(R.id.splashProgress);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Unitech_ActivitySplash.this, MainActivity.class));
            }
        }, 100);

    }




}