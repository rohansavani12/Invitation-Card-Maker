package com.invitationcardmaker.edigitalcard.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Priority;
import com.bumptech.glide.request.RequestOptions;

import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.listener.CustomItemClickListener;
import com.invitationcardmaker.edigitalcard.main.AllConstants;
import com.invitationcardmaker.edigitalcard.main.BGImageActivity;
import com.invitationcardmaker.edigitalcard.main.OnClickCallback;
import com.invitationcardmaker.edigitalcard.pojoClass.BackgroundImage;
import com.invitationcardmaker.edigitalcard.utility.GlideImageLoader1;

import java.util.ArrayList;

public class Adapters extends RecyclerView.Adapter<Adapters.ViewHolder> {
    public ArrayList<BackgroundImage> backgroundImages;
    Context context;
    int flagForActivity;
    int i1;
    private int index;
    CustomItemClickListener listener;
    private boolean mHorizontal;
    private boolean mPager;
    public OnClickCallback<ArrayList<String>, Integer, String, Activity, String> mSingleCallback;
    SharedPreferences preferences;
    ProgressDialog progress;

    public Adapters(Context context2, boolean z, boolean z2, ArrayList<BackgroundImage> arrayList, int i, int i2, CustomItemClickListener customItemClickListener) {
        this.mHorizontal = z;
        this.backgroundImages = arrayList;
        this.mPager = z2;
        this.context = context2;
        this.flagForActivity = i;
        this.index = i2;
        this.preferences = PreferenceManager.getDefaultSharedPreferences(context2);
        this.listener = customItemClickListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (this.mPager) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_pager, viewGroup, false));
        }
        if (this.mHorizontal) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter, viewGroup, false));
        }
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_vertical, viewGroup, false));
    }


    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        RequestOptions requestOptions;
        this.backgroundImages.get(i);
        final String str = AllConstants.BASE_URL_BG + "/" + this.backgroundImages.get(i).getImage_url();
        if (i > 4) {
            viewHolder.ivLock.setVisibility(8);
            viewHolder.imageView.setVisibility(4);
            viewHolder.rl_see_more.setVisibility(0);
            viewHolder.rl_see_more.setOnClickListener(new View.OnClickListener() {
                /* class com.invitationcardmaker.edigitalcard.adapter.Adapters.AnonymousClass1 */

                public void onClick(View view) {
                    if (Adapters.this.listener != null) {
                        Adapters.this.listener.onItemClick(i);
                    }
                }
            });
            return;
        }
        if (this.index > 1) {
            requestOptions = (RequestOptions) new RequestOptions().priority(Priority.HIGH);
        } else {
            requestOptions = (RequestOptions) new RequestOptions().priority(Priority.HIGH);
        }
        new GlideImageLoader1(viewHolder.imageView, viewHolder.mProgressBar).load(AllConstants.BASE_URL_BG + "/" + this.backgroundImages.get(i).getThumb_url(), requestOptions);
        if (i <= 11 || this.preferences.getBoolean("isAdsDisabled", false)) {
            viewHolder.ivLock.setVisibility(8);
        } else {
            viewHolder.ivLock.setVisibility(8);
        }
        viewHolder.imageView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if (Adapters.this.flagForActivity == 1) {
                    ((BGImageActivity) Adapters.this.context).onGetPosition(str);
                } else {
                    Adapters.this.mSingleCallback.onClickCallBack(null, Adapters.this.backgroundImages, str, (FragmentActivity) Adapters.this.context, "");
                }
            }
        });
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @SuppressLint("MissingPermission")
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void LoadInter_AD(final String str, final int i) {
        if (Adapters.this.progress.isShowing()) {
            Adapters.this.progress.dismiss();
        }
        if (Adapters.this.i1 == 1) {
            if (Adapters.this.flagForActivity == 1) {
                ((BGImageActivity) Adapters.this.context).onGetPosition(str);
            } else {
                Adapters.this.mSingleCallback.onClickCallBack(null, Adapters.this.backgroundImages, str, (FragmentActivity) Adapters.this.context, "");
            }
        }
        if (Adapters.this.i1 == 2 && Adapters.this.listener != null) {
            Adapters.this.listener.onItemClick(i);
        }

    }


    public void setItemClickCallback(OnClickCallback onClickCallback) {
        this.mSingleCallback = onClickCallback;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i) {
        return super.getItemViewType(i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.backgroundImages.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView imageView;
        ImageView ivLock;
        public ProgressBar mProgressBar;
        public TextView nameTextView;
        public TextView ratingTextView;
        public RelativeLayout rl_see_more;

        public void onClick(View view) {
        }

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            this.imageView = (ImageView) view.findViewById(R.id.imageView);
            this.ivLock = (ImageView) view.findViewById(R.id.iv_lock);
            this.nameTextView = (TextView) view.findViewById(R.id.nameTextView);
            this.ratingTextView = (TextView) view.findViewById(R.id.ratingTextView);
            this.mProgressBar = (ProgressBar) view.findViewById(R.id.progressBar1);
            this.rl_see_more = (RelativeLayout) view.findViewById(R.id.rl_see_more);
        }
    }
}