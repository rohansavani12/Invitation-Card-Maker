package com.invitationcardmaker.edigitalcard.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.DownloadListener;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.invitationcardmaker.edigitalcard.InvitationApplication;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_activity.IntegerVersionSignature;
import com.invitationcardmaker.edigitalcard.main.AllConstants;
import com.invitationcardmaker.edigitalcard.main.OnClickCallback;
import com.invitationcardmaker.edigitalcard.pojoClass.BackgroundImage;
import com.invitationcardmaker.edigitalcard.utils.PreferenceClass;
import java.util.ArrayList;
import java.util.List;

public class BackgroundAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final String TAG = "BackgroundAdapter";
    public final int VIEW_TYPE_ITEM = 0;
    public final int VIEW_TYPE_LOADING = 1;
    private PreferenceClass appPreference;
    ArrayList<BackgroundImage> category_list;
    Activity context;
    int i;
    boolean isDownloadProgress = true;
    public OnClickCallback<ArrayList<String>, Integer, String, Activity, String> mSingleCallback;
    ProgressDialog progress;

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public long getItemId(int i2) {
        return (long) i2;
    }

    public BackgroundAdapter(Activity activity, ArrayList<BackgroundImage> arrayList) {
        this.context = activity;
        this.appPreference = new PreferenceClass(activity);
        this.category_list = arrayList;
    }

    public static String getFileNameFromUrl(String str) {
        return str.substring(str.lastIndexOf(47) + 1).split("\\?")[0].split("#")[0];
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        ArrayList<BackgroundImage> arrayList = this.category_list;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i2) {
        if (getItemViewType(i2) == 0) {
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            viewHolder2.downloadProgress.setVisibility(8);
            final String str = AllConstants.BASE_URL_BG + "/" + this.category_list.get(i2).getImage_url();
            viewHolder2.imgDownload.setVisibility(8);
            Glide.with(this.context).load(AllConstants.BASE_URL_BG + "/" + this.category_list.get(i2).getThumb_url()).thumbnail(0.1f).apply(((RequestOptions) ((RequestOptions) ((RequestOptions) ((RequestOptions) ((RequestOptions) ((RequestOptions) new RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL)).signature(new IntegerVersionSignature(AllConstants.getVersionInfo()))).dontAnimate()).override(200, 200)).fitCenter()).placeholder(R.drawable.no_image)).error(R.drawable.no_image)).into(viewHolder2.imageView);
            viewHolder2.layout.setOnClickListener(new View.OnClickListener() {
                /* class com.invitationcardmaker.edigitalcard.adapter.BackgroundAdapter.AnonymousClass1 */

                public void onClick(View view) {
                    if (BackgroundAdapter.this.isNetworkConnected()) {
                        BackgroundAdapter.this.progress = new ProgressDialog(BackgroundAdapter.this.context);
                        BackgroundAdapter.this.progress.setTitle("Loading");
                        BackgroundAdapter.this.progress.setMessage("Wait while loading...");
                        BackgroundAdapter.this.progress.setCancelable(false);
                        BackgroundAdapter.this.progress.show();
                        InvitationApplication.onAddclick = 0;
//                        BackgroundAdapter.this.LoadInter_AD(str);
                    } else {
                        try {
                            BackgroundAdapter.this.mSingleCallback.onClickCallBack(null, BackgroundAdapter.this.category_list, str, BackgroundAdapter.this.context, "");
                        } catch (NullPointerException e2) {
                            e2.printStackTrace();
                        }
                    }
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @SuppressLint("MissingPermission")
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }




    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i2) {
        if (i2 == 0) {
            return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.unitech_background_image_listrow, viewGroup, false));
        }
        return new LoadingHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.progress_view, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i2) {
        return this.category_list.get(i2) == null ? 1 : 0;
    }

    public void addData(List<BackgroundImage> list) {
        notifyDataSetChanged();
    }

    public void removeLoadingView() {
        ArrayList<BackgroundImage> arrayList = this.category_list;
        arrayList.remove(arrayList.size() - 1);
        notifyItemRemoved(this.category_list.size());
    }

    public void addLoadingView() {
        new Handler().post(new Runnable() {
            /* class com.invitationcardmaker.edigitalcard.adapter.BackgroundAdapter.AnonymousClass4 */

            public void run() {
                BackgroundAdapter.this.category_list.add(null);
                BackgroundAdapter backgroundAdapter = BackgroundAdapter.this;
                backgroundAdapter.notifyItemInserted(backgroundAdapter.category_list.size() - 1);
            }
        });
    }

    public void DownoloadSticker(String str, String str2, String str3) {
        AndroidNetworking.download(str, str2, str3).build().startDownload(new DownloadListener() {
            /* class com.invitationcardmaker.edigitalcard.adapter.BackgroundAdapter.AnonymousClass5 */

            @Override // com.androidnetworking.interfaces.DownloadListener
            public void onDownloadComplete() {
                BackgroundAdapter.this.isDownloadProgress = true;
                BackgroundAdapter.this.notifyDataSetChanged();
                Log.e(BackgroundAdapter.TAG, "onDownloadComplete: ");
            }

            @Override // com.androidnetworking.interfaces.DownloadListener
            public void onError(ANError aNError) {
                BackgroundAdapter.this.isDownloadProgress = true;
                BackgroundAdapter.this.notifyDataSetChanged();
                Log.e(BackgroundAdapter.TAG, "onError: ");
                Toast.makeText(BackgroundAdapter.this.context, "Network Error", 0).show();
            }
        });
    }

    public void setItemClickCallback(OnClickCallback onClickCallback) {
        this.mSingleCallback = onClickCallback;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ProgressBar downloadProgress;
        ImageView imageView;
        RelativeLayout imgDownload;
        LinearLayout layout;

        public ViewHolder(View view) {
            super(view);
            this.imgDownload = (RelativeLayout) view.findViewById(R.id.imgDownload);
            this.imageView = (ImageView) view.findViewById(R.id.thumbnail_image);
            this.layout = (LinearLayout) view.findViewById(R.id.main);
            this.downloadProgress = (ProgressBar) view.findViewById(R.id.downloadProgress);
        }
    }

    public class LoadingHolder extends RecyclerView.ViewHolder {
        public LoadingHolder(View view) {
            super(view);
        }
    }
}