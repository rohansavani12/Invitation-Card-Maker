package com.invitationcardmaker.edigitalcard.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.github.rubensousa.gravitysnaphelper.GravityPagerSnapHelper;
import com.github.rubensousa.gravitysnaphelper.GravitySnapHelper;

import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.listener.CustomItemClickListener;
import com.invitationcardmaker.edigitalcard.main.BGImageActivity;
import com.invitationcardmaker.edigitalcard.main.OnClickCallback;
import com.invitationcardmaker.edigitalcard.pojoClass.BackgroundImage;
import com.invitationcardmaker.edigitalcard.pojoClass.Snap;
import java.util.ArrayList;
import java.util.List;

public class VeticalViewBgAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements GravitySnapHelper.SnapListener {
    private static final int PROGESS_VIEW = 0;
    private static final int VIEW_ITEM = 1;
    Activity context;
    int flagForActivity;
    int i;
    public OnClickCallback<ArrayList<String>, Integer, String, Activity, String> mSingleCallback;
    public ArrayList<Object> mSnaps;
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        /* class com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter.AnonymousClass1 */

        public boolean onTouch(View view, MotionEvent motionEvent) {
            view.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        }
    };
    ProgressDialog progress;
    RecyclerView recyclerView;

    @Override // com.github.rubensousa.gravitysnaphelper.GravitySnapHelper.SnapListener
    public void onSnap(int i2) {
    }

    public VeticalViewBgAdapter(Activity activity, ArrayList<Object> arrayList, RecyclerView recyclerView2, int i2) {
        this.mSnaps = arrayList;
        this.context = activity;
        this.flagForActivity = i2;
        this.recyclerView = recyclerView2;
    }

    public void addSnap(Snap snap) {
        this.mSnaps.add(snap);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i2) {
        return this.mSnaps.get(i2) == null ? 0 : 1;
    }

    public void addData(List<Object> list) {
        notifyDataSetChanged();
    }

    public void addLoadingView() {
        new Handler().post(new Runnable() {
            /* class com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter.AnonymousClass2 */

            public void run() {
                VeticalViewBgAdapter.this.mSnaps.add(null);
                VeticalViewBgAdapter veticalViewBgAdapter = VeticalViewBgAdapter.this;
                veticalViewBgAdapter.notifyItemInserted(veticalViewBgAdapter.mSnaps.size() - 1);
            }
        });
    }

    public void removeLoadingView() {
        ArrayList<Object> arrayList = this.mSnaps;
        arrayList.remove(arrayList.size() - 1);
        notifyItemRemoved(this.mSnaps.size());
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i2) {
        if (i2 == 0) {
            return new LoadingHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.progress_view, viewGroup, false));
        }
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.unitech_adapter_snap, viewGroup, false));
    }

    public void setItemClickCallback(OnClickCallback onClickCallback) {
        this.mSingleCallback = onClickCallback;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i2) {
        if (getItemViewType(i2) == 1) {
            final ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            final Snap snap = (Snap) this.mSnaps.get(i2);
            snap.getText().toUpperCase().contains("WHITE");
            viewHolder2.snapTextView.setText(snap.getText().replace("white", "").toUpperCase());
            viewHolder2.recyclerView.setOnFlingListener(null);
            boolean z = false;
            if (snap.getGravity() == 8388611 || snap.getGravity() == 8388613) {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext(), 0, false));
                new GravitySnapHelper(snap.getGravity()).attachToRecyclerView(viewHolder2.recyclerView);
            } else if (snap.getGravity() == 1 || snap.getGravity() == 16) {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext(), snap.getGravity() == 1 ? 0 : 1, false));
                new LinearSnapHelper().attachToRecyclerView(viewHolder2.recyclerView);
            } else if (snap.getGravity() == 17) {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext(), 0, false));
                new GravityPagerSnapHelper(GravityCompat.START).attachToRecyclerView(viewHolder2.recyclerView);
            } else {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext()));
                new GravitySnapHelper(snap.getGravity()).attachToRecyclerView(viewHolder2.recyclerView);
            }
            if (snap.getBackgroundImages().size() > 3) {
                viewHolder2.seeMoreTextView.setVisibility(0);
            } else {
                viewHolder2.seeMoreTextView.setVisibility(8);
            }
            ArrayList<BackgroundImage> arrayList = new ArrayList<>();
            if (snap.getBackgroundImages().size() >= 6) {
                for (int i3 = 0; i3 < 6; i3++) {
                    arrayList.add(snap.getBackgroundImages().get(i3));
                }
            } else {
                arrayList = snap.getBackgroundImages();
            }
            if (this.flagForActivity == 1) {
                Activity activity = this.context;
                boolean z2 = snap.getGravity() == 8388611 || snap.getGravity() == 8388613 || snap.getGravity() == 1;
                if (snap.getGravity() == 17) {
                    z = true;
                }
                viewHolder2.recyclerView.setAdapter(new Adapters(activity, z2, z, arrayList, this.flagForActivity, i2, new CustomItemClickListener() {
                    /* class com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter.AnonymousClass3 */

                    @Override // com.invitationcardmaker.edigitalcard.listener.CustomItemClickListener
                    public void onItemClick(int i) {
                        viewHolder2.seeMoreTextView.performClick();
                    }
                }));
            } else {
                Activity activity2 = this.context;
                boolean z3 = snap.getGravity() == 8388611 || snap.getGravity() == 8388613 || snap.getGravity() == 1;
                if (snap.getGravity() == 17) {
                    z = true;
                }
                Adapters adapters = new Adapters(activity2, z3, z, arrayList, this.flagForActivity, i2, new CustomItemClickListener() {
                    /* class com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter.AnonymousClass4 */

                    @Override // com.invitationcardmaker.edigitalcard.listener.CustomItemClickListener
                    public void onItemClick(int i) {
                        viewHolder2.seeMoreTextView.performClick();
                    }
                });
                viewHolder2.recyclerView.setAdapter(adapters);
                adapters.setItemClickCallback(new OnClickCallback<ArrayList<String>, Integer, String, Activity, String>() {
                    /* class com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter.AnonymousClass5 */

                    @Override // com.invitationcardmaker.edigitalcard.main.OnClickCallback
                    public void onClickCallBack(ArrayList<String> arrayList, ArrayList<BackgroundImage> arrayList2, String str, Activity activity, String str2) {
                        VeticalViewBgAdapter.this.mSingleCallback.onClickCallBack(null, arrayList2, str, VeticalViewBgAdapter.this.context, "");
                    }
                });
            }
            viewHolder2.seeMoreTextView.setOnClickListener(new View.OnClickListener() {
                /* class com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter.AnonymousClass6 */

                public void onClick(View view) {
                    Log.d("rrr", "onClick: ");
                    if (VeticalViewBgAdapter.this.flagForActivity == 1) {
                        ((BGImageActivity) VeticalViewBgAdapter.this.context).itemClickSeeMoreAdapter(snap.getBackgroundImages(), snap.getText());
                    } else {
                        VeticalViewBgAdapter.this.mSingleCallback.onClickCallBack(null, snap.getBackgroundImages(), "", VeticalViewBgAdapter.this.context, "");
                    }
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @SuppressLint("MissingPermission")
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void LoadInter_AD(final Snap snap) {
        if (VeticalViewBgAdapter.this.progress.isShowing()) {
            VeticalViewBgAdapter.this.progress.dismiss();
        }
        if (VeticalViewBgAdapter.this.flagForActivity == 1) {
            ((BGImageActivity) VeticalViewBgAdapter.this.context).itemClickSeeMoreAdapter(snap.getBackgroundImages(), snap.getText());
        } else {
            VeticalViewBgAdapter.this.mSingleCallback.onClickCallBack(null, snap.getBackgroundImages(), "", VeticalViewBgAdapter.this.context, "");
        }

    }


    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.mSnaps.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public RecyclerView recyclerView;
        public TextView seeMoreTextView;
        public TextView snapTextView;

        public ViewHolder(View view) {
            super(view);
            this.snapTextView = (TextView) view.findViewById(R.id.snapTextView);
            this.seeMoreTextView = (TextView) view.findViewById(R.id.seeMoreTextView);
            this.recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        }
    }

    public class LoadingHolder extends RecyclerView.ViewHolder {
        public LoadingHolder(View view) {
            super(view);
        }
    }
}