package com.invitationcardmaker.edigitalcard.adapter;

import android.widget.ImageView;

/* loaded from: classes2.dex */
class ViewHolder {
    ImageView imageview;
    ImageView imgDeletePoster;
}
