package com.invitationcardmaker.edigitalcard.adapterMaster;

import android.app.Activity;
import android.app.ProgressDialog;
import android.net.ConnectivityManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.github.rubensousa.gravitysnaphelper.GravityPagerSnapHelper;
import com.github.rubensousa.gravitysnaphelper.GravitySnapHelper;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.main.InvitationCatActivity;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterThumbFull;
import com.invitationcardmaker.edigitalcard.pojoClass.Snap1;
import java.util.ArrayList;
import java.util.List;

public class PosterSnapAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements GravitySnapHelper.SnapListener {
    private static final int PROGESS_VIEW = 0;
    private static final int VIEW_ITEM = 1;
    Activity context;
    int i;
    private boolean isLoaderVisible = false;
    private ArrayList<Object> mSnaps;
    ProgressDialog progress;

    public PosterSnapAdapter(Activity activity, ArrayList<Object> arrayList) {
        this.mSnaps = arrayList;
        this.context = activity;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i2) {
        return (!this.isLoaderVisible || i2 != this.mSnaps.size() - 1) ? 1 : 0;
    }

    public void addSnap(Snap1 snap1) {
        this.mSnaps.add(snap1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i2) {
        if (i2 == 0) {
            return new LoadingHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.progress_view, viewGroup, false));
        }
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.unitech_adapter_snap, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i2) {
        if (getItemViewType(i2) == 1) {
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            final Snap1 snap1 = (Snap1) this.mSnaps.get(i2);
            if (snap1.getPosterThumbFulls().size() == 0) {
                viewHolder2.llItem.setVisibility(8);
            } else {
                viewHolder2.llItem.setVisibility(0);
            }
            viewHolder2.snapTextView.setText(snap1.getText().toUpperCase());
            viewHolder2.recyclerView.setOnFlingListener(null);
            if (snap1.getGravity() == 8388611 || snap1.getGravity() == 8388613) {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext(), 0, false));
                new GravitySnapHelper(snap1.getGravity(), false, this).attachToRecyclerView(viewHolder2.recyclerView);
            } else if (snap1.getGravity() == 1 || snap1.getGravity() == 16) {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext(), snap1.getGravity() == 1 ? 0 : 1, false));
                new LinearSnapHelper().attachToRecyclerView(viewHolder2.recyclerView);
            } else if (snap1.getGravity() == 17) {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext(), 0, false));
                new GravityPagerSnapHelper(GravityCompat.START).attachToRecyclerView(viewHolder2.recyclerView);
            } else {
                viewHolder2.recyclerView.setLayoutManager(new LinearLayoutManager(viewHolder2.recyclerView.getContext()));
                new GravitySnapHelper(snap1.getGravity()).attachToRecyclerView(viewHolder2.recyclerView);
            }
            ArrayList<PosterThumbFull> arrayList = new ArrayList<>();
            if (snap1.getPosterThumbFulls().size() >= 5) {
                for (int i3 = 0; i3 < 5; i3++) {
                    arrayList.add(snap1.getPosterThumbFulls().get(i3));
                }
            } else {
                arrayList = snap1.getPosterThumbFulls();
            }
            viewHolder2.recyclerView.setAdapter(new PosterCategoryWithListAdapter(this.context, snap1.getCat_id(), snap1.getGravity() == 8388611 || snap1.getGravity() == 8388613 || snap1.getGravity() == 1, snap1.getGravity() == 17, arrayList, snap1.getRatio()));
            viewHolder2.seeMoreTextView.setOnClickListener(new View.OnClickListener() {
                /* class com.invitationcardmaker.edigitalcard.adapterMaster.PosterSnapAdapter.AnonymousClass1 */

                public void onClick(View view) {
                        ((InvitationCatActivity) PosterSnapAdapter.this.context).itemClickSeeMoreAdapter(snap1.getPosterThumbFulls(), snap1.getCat_id(), snap1.getText(), snap1.getRatio());
                }
            });
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void addData(List<Object> list) {
        if (this.mSnaps.size() > 0) {
            this.mSnaps.addAll(list);
            notifyItemChanged(list.size(), false);
            return;
        }
        this.mSnaps.addAll(list);
        notifyDataSetChanged();
    }

    public void addLoadingView() {
        this.isLoaderVisible = true;
        this.mSnaps.add(new PosterThumbFull());
        notifyItemInserted(this.mSnaps.size() - 1);
    }

    public void removeLoadingView() {
        this.isLoaderVisible = false;
        int size = this.mSnaps.size() - 1;
        if (getItem(size) != null) {
            this.mSnaps.remove(size);
            notifyItemRemoved(size);
        }
    }

    private Object getItem(int i2) {
        return this.mSnaps.get(i2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        ArrayList<Object> arrayList = this.mSnaps;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    @Override // com.github.rubensousa.gravitysnaphelper.GravitySnapHelper.SnapListener
    public void onSnap(int i2) {
        Log.d("Snapped: ", i2 + "");
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llItem;
        public RecyclerView recyclerView;
        public TextView seeMoreTextView;
        public TextView snapTextView;

        ViewHolder(View view) {
            super(view);
            this.snapTextView = (TextView) view.findViewById(R.id.snapTextView);
            this.seeMoreTextView = (TextView) view.findViewById(R.id.seeMoreTextView);
            this.recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
            this.llItem = (LinearLayout) view.findViewById(R.id.ll_item);
        }
    }

    public class LoadingHolder extends RecyclerView.ViewHolder {
        public LoadingHolder(View view) {
            super(view);
        }
    }
}