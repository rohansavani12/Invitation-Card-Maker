package com.invitationcardmaker.edigitalcard.callApi;

import com.invitationcardmaker.edigitalcard.main.AllConstants;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/* loaded from: classes2.dex */
public class ApiClientBack {
    public static final String BASE_URL = AllConstants.BASE_URL_BG;
    private static Retrofit retrofit1 = null;

    public static Retrofit getClient() {
        if (retrofit1 == null) {
            retrofit1 = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        }
        return retrofit1;
    }
}
