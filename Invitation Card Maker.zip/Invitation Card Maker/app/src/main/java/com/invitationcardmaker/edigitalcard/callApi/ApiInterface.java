package com.invitationcardmaker.edigitalcard.callApi;

import com.invitationcardmaker.edigitalcard.pojoClass.Advertise;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterBG;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterCategoryList;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterInfo;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterKey;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterThumb;
import com.invitationcardmaker.edigitalcard.pojoClass.PosterWithList;
import com.invitationcardmaker.edigitalcard.pojoClass.ThumbBG;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/* loaded from: classes2.dex */
public interface ApiInterface {
    @GET("ads/ninvitation.php")
    Call<Advertise> getAdvertise();

    @FormUrlEncoded
    @POST("poster/background")
    Call<PosterBG> getBackground(@Field("device") int i);

    @FormUrlEncoded
    @POST("poster/backgroundlatest")
    Call<ThumbBG> getBackgrounds(@Field("device") int i);

    @FormUrlEncoded
    @POST("poster/category")
    Call<PosterCategoryList> getPosterCatList(@Field("key") String str, @Field("device") int i);

    @FormUrlEncoded
    @POST("poster/swiperCat")
    Call<PosterWithList> getPosterCatListFull(@Field("key") String str, @Field("device") int i, @Field("cat_id") int i2, @Field("ratio") String str2);

    @FormUrlEncoded
    @POST("poster/poster")
    Call<PosterInfo> getPosterDetails(@Field("key") String str, @Field("device") int i, @Field("cat_id") int i2, @Field("post_id") int i3);

    @FormUrlEncoded
    @POST("apps_key")
    Call<PosterKey> getPosterKey(@Field("device") int i);

    @FormUrlEncoded
    @POST("poster/poster")
    Call<PosterThumb> getPosterThumbList(@Field("key") String str, @Field("device") int i, @Field("cat_id") int i2);
}
