package com.invitationcardmaker.edigitalcard.colorpicker;

/* loaded from: classes2.dex */
public interface OnColorChangedListener {
    void onColorChanged(int i);
}
