package com.invitationcardmaker.edigitalcard.handler;

import java.io.Serializable;

/* loaded from: classes2.dex */
public class BitmapDataObject implements Serializable {
    private static final long serialVersionUID = 111696345129311948L;
    public byte[] imageByteArray;
}
