package com.invitationcardmaker.edigitalcard.handler;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.main.CreateCardActivity;

/* loaded from: classes2.dex */
public class BlurOperationAsync extends AsyncTask<String, Void, String> {
    Activity context;
    private ProgressDialog f227pd;

    public String doInBackground(String... strArr) {
        return "yes";
    }

    public BlurOperationAsync(CreateCardActivity createCardActivity) {
        this.context = createCardActivity;
    }

    @Override // android.os.AsyncTask
    public void onPreExecute() {
        ProgressDialog progressDialog = new ProgressDialog(this.context);
        this.f227pd = progressDialog;
        progressDialog.setMessage(this.context.getResources().getString(R.string.plzwait));
        this.f227pd.setCancelable(false);
        this.f227pd.show();
    }

    public void onPostExecute(String str) {
        this.f227pd.dismiss();
    }
}
