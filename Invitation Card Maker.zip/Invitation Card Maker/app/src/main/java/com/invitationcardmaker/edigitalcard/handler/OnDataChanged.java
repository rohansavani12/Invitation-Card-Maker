package com.invitationcardmaker.edigitalcard.handler;

/* loaded from: classes2.dex */
public interface OnDataChanged {
    void updateAdapter();

    void updateInstLay(boolean z);
}
