package com.invitationcardmaker.edigitalcard.listener;

/* loaded from: classes2.dex */
public interface GetSnapListener {
    void onSnapFilter(int i, int i2, String str);
}
