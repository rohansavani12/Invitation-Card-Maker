package com.invitationcardmaker.edigitalcard.listener;

/* loaded from: classes2.dex */
public interface OnClickCallback<T, P, A, V> {
    void onClickCallBack(T t, P p, A a, V v);
}
