package com.invitationcardmaker.edigitalcard.main;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.google.android.gms.common.internal.ImagesContract;
import com.google.gson.Gson;

import com.invitationcardmaker.edigitalcard.InvitationApplication;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_activity.Unitech_BaseActivity;
import com.invitationcardmaker.edigitalcard.adapter.RecyclerViewLoadMoreScroll;
import com.invitationcardmaker.edigitalcard.adapter.VeticalViewBgAdapter;
import com.invitationcardmaker.edigitalcard.fragment.BackgroundFragment1;
import com.invitationcardmaker.edigitalcard.listener.GetSnapListener;
import com.invitationcardmaker.edigitalcard.listener.OnLoadMoreListener;
import com.invitationcardmaker.edigitalcard.network.NetworkConnectivityReceiver;
import com.invitationcardmaker.edigitalcard.pojoClass.BackgroundImage;
import com.invitationcardmaker.edigitalcard.pojoClass.MainBG;
import com.invitationcardmaker.edigitalcard.pojoClass.Snap;
import com.invitationcardmaker.edigitalcard.pojoClass.ThumbBG;
import com.invitationcardmaker.edigitalcard.pojoClass.YourDataProvider;
import com.invitationcardmaker.edigitalcard.utils.Config;
import com.invitationcardmaker.edigitalcard.utils.Configure;
import com.invitationcardmaker.edigitalcard.utils.PreferenceClass;
import com.invitationcardmaker.edigitalcard.ucrop.UCrop;
import com.invitationcardmaker.edigitalcard.ucrop.model.AspectRatio;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import yuku.ambilwarna.AmbilWarnaDialog;

/* loaded from: classes2.dex */
public class BGImageActivity extends Unitech_BaseActivity implements View.OnClickListener, GetSnapListener, GetSnapListenerS {
    private static final int SELECT_PICTURE_FROM_CAMERA = 9062;
    private static final int SELECT_PICTURE_FROM_GALLERY = 9072;
    public static final String TAG = "BackgrounImageActivity";

    AspectRatio[] aspectRatioArr;
    private ImageView btnBack;
    private ImageView btnColorPicker;
    private ImageView btnGalleryPicker;
    private ImageView btnTakePicture;
    public ProgressDialog dialogIs;
    private File f230f;
    FrameLayout frameBanner;
    Uri fromFile;
    private int height;
    int i1;
    private ProgressBar loading_view;
    LinearLayoutManager mLinearLayoutManager;
    private RecyclerView mRecyclerView;
    UCrop.Options options;
    public PreferenceClass preferenceClass;
    private SharedPreferences preferences;
    ProgressDialog progress;
    private String ratio;
    private Uri resultUri;
    float screenHeight;
    float screenWidth;
    public RecyclerViewLoadMoreScroll scrollListener;
    String str3;
    private int totalAds;
    private TextView txtTitle;
    public VeticalViewBgAdapter veticalViewAdapter;
    private int widht;
    YourDataProvider yourDataProvider;
    private final int bColor = Color.parseColor("#4149b6");
    private int cnt = 0;
    private final int isFirstLoad = 0;
    ArrayList<Object> snapData = new ArrayList<>();
    ArrayList<MainBG> thumbnail_bg = new ArrayList<>();

    @Override
    // com.invitationcardmaker.edigitalcard.activity.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        getWindow().setFlags(1024, 1024);
        super.onCreate(bundle);
        setContentView(R.layout.unitech_activity_bg_image);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.layoutBannerAd);
        this.frameBanner = frameLayout;
        this.loading_view = (ProgressBar) findViewById(R.id.loading_view);
        this.mRecyclerView = (RecyclerView) findViewById(R.id.background_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        this.mLinearLayoutManager = linearLayoutManager;
        this.mRecyclerView.setLayoutManager(linearLayoutManager);
        this.mRecyclerView.setHasFixedSize(true);
        Config.SaveInt("flow", 1, this);
        this.preferences = PreferenceManager.getDefaultSharedPreferences(this);
        findViews();
        this.preferenceClass = new PreferenceClass(this);
        if (NetworkConnectivityReceiver.isConnected() && !this.preferenceClass.getBoolean("isAdsDisabled", false) && InvitationApplication.advertise != null) {
            InvitationApplication.advertise.getFlag().equalsIgnoreCase("1");
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.screenWidth = (float) displayMetrics.widthPixels;
        this.screenHeight = (float) displayMetrics.heightPixels;
        getBgImages();
    }

    private void getBgImages() {
        InvitationApplication instance = InvitationApplication.getInstance();
        instance.addToRequestQueue(new StringRequest(1, AllConstants.BASE_URL_POSTER_BG + "poster/backgroundlatest", new Response.Listener<String>() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.2
            public void onResponse(String str) {
                try {
                    ThumbBG thumbBG = (ThumbBG) new Gson().fromJson(str, ThumbBG.class);
                    if (thumbBG != null && thumbBG.getThumbnail_bg() != null && thumbBG.getThumbnail_bg().size() > 0) {
                        BGImageActivity.this.thumbnail_bg = new ArrayList<>();
                        BGImageActivity.this.thumbnail_bg = thumbBG.getThumbnail_bg();
                        BGImageActivity.this.setupAdapter();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.3
            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError volleyError) {
                Log.e(BGImageActivity.TAG, "Error: " + volleyError.getMessage());
            }
        }) { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.4
            @Override // com.android.volley.Request
            public Map<String, String> getParams() {
                HashMap hashMap = new HashMap();
                hashMap.put("device", "1");
                return hashMap;
            }
        }, TAG);
    }

    public void setupAdapter() {
        for (int i = 0; i < this.thumbnail_bg.size(); i++) {
            this.snapData.add(new Snap(1, this.thumbnail_bg.get(i).getCategory_name(), this.thumbnail_bg.get(i).getCategory_list()));
        }
        this.loading_view.setVisibility(8);
        YourDataProvider yourDataProvider = new YourDataProvider();
        this.yourDataProvider = yourDataProvider;
        yourDataProvider.setPosterList(this.snapData);
        if (this.snapData != null) {
            VeticalViewBgAdapter veticalViewBgAdapter = new VeticalViewBgAdapter(this, this.yourDataProvider.getLoadMorePosterItems(), this.mRecyclerView, 1);
            this.veticalViewAdapter = veticalViewBgAdapter;
            this.mRecyclerView.setAdapter(veticalViewBgAdapter);
            RecyclerViewLoadMoreScroll recyclerViewLoadMoreScroll = new RecyclerViewLoadMoreScroll(this.mLinearLayoutManager);
            this.scrollListener = recyclerViewLoadMoreScroll;
            recyclerViewLoadMoreScroll.setOnLoadMoreListener(new OnLoadMoreListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.5
                @Override // com.invitationcardmaker.edigitalcard.listener.OnLoadMoreListener
                public void onLoadMore() {
                    BGImageActivity.this.LoadMoreData();
                }
            });
            this.mRecyclerView.addOnScrollListener(this.scrollListener);
        }
        this.loading_view.setVisibility(8);
    }

    public void LoadMoreData() {
        this.veticalViewAdapter.addLoadingView();
        new Handler().postDelayed(new Runnable() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.6
            @Override // java.lang.Runnable
            public void run() {
                BGImageActivity.this.veticalViewAdapter.removeLoadingView();
                BGImageActivity.this.veticalViewAdapter.addData(BGImageActivity.this.yourDataProvider.getLoadMorePosterItemsS());
                BGImageActivity.this.veticalViewAdapter.notifyDataSetChanged();
                BGImageActivity.this.scrollListener.setLoaded();
            }
        }, 3000);
    }

    public File getCacheFolder(Context context) {
        File GetFileDir = Configure.GetFileDir(context);
        GetFileDir.mkdirs();
        return GetFileDir;
    }

    public void onGetPosition(String str) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        this.dialogIs = progressDialog;
        progressDialog.setMessage(getResources().getString(R.string.plzwait));
        this.dialogIs.setCancelable(false);
        this.dialogIs.show();
        InvitationApplication.getInstance().addToRequestQueue(new ImageRequest(str, new GetPositionResponseListener(this, getCacheFolder(this)), 0, 0, ImageView.ScaleType.CENTER_CROP, Bitmap.Config.RGB_565, new Response.ErrorListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.7
            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError volleyError) {
                BGImageActivity.this.dialogIs.dismiss();
            }
        }));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:11:0x00d8
        	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1148)
        	at jadx.core.dex.visitors.regions.RegionMaker.processTryCatchBlocks(RegionMaker.java:1019)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:55)
        */
    public void onGetPositionResponseReceived(File file, Bitmap bitmap) {
        try {
            this.dialogIs.dismiss();
            try {
                File file2 = new File(file, "localFileName.png");
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                try {
                    Uri fromFile2 = Uri.fromFile(file2);
                    Uri fromFile3 = Uri.fromFile(new File(file, "SampleCropImage" + System.currentTimeMillis() + ".png"));
                    UCrop.Options options2 = new UCrop.Options();
                    options2.setToolbarColor(getResources().getColor(R.color.colorPrimary));
                    options2.setAspectRatioOptions(2, new AspectRatio("1:1", 1.0f, 1.0f), new AspectRatio("3:2", 3.0f, 2.0f), new AspectRatio("2:3", 2.0f, 3.0f), new AspectRatio("4:3", 4.0f, 3.0f), new AspectRatio("3:4", 3.0f, 4.0f), new AspectRatio("16:9", 16.0f, 9.0f), new AspectRatio("5:4", 5.0f, 4.0f), new AspectRatio("4:5", 4.0f, 5.0f));
                    UCrop.m79of(fromFile2, fromFile3).withOptions(options2).start(this);
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
            } catch (IOException e3) {
                e3.printStackTrace();
            }
        } catch (Exception e4) {
            e4.printStackTrace();
        }
    }



    public void itemClickSeeMoreAdapter(ArrayList<BackgroundImage> arrayList, String str) {
        seeMore(arrayList);
    }

    private void seeMore(ArrayList<BackgroundImage> arrayList) {
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
        BackgroundFragment1 backgroundFragment1 = (BackgroundFragment1) supportFragmentManager.findFragmentByTag("back_category_frgm");
        if (backgroundFragment1 != null) {
            beginTransaction.remove(backgroundFragment1);
        }
        beginTransaction.add(R.id.frameContainerBackground, BackgroundFragment1.newInstance(arrayList), "back_category_frgm");
        beginTransaction.addToBackStack("back_category_frgm");
        try {
            beginTransaction.commitAllowingStateLoss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        freeMemory();
    }

    public void freeMemory() {
        try {
            new Thread(new Runnable() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.8
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Glide.get(BGImageActivity.this).clearDiskCache();
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            Glide.get(this).clearMemory();
        } catch (Exception e) {
            e.printStackTrace();
        } catch (OutOfMemoryError e2) {
            e2.printStackTrace();
        }
        System.runFinalization();
        Runtime.getRuntime().gc();
        System.gc();
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x022b  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x023c  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0240  */
    @Override
    // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void onActivityResult(int i, int i2, Intent intent) {
        String str;
        String str2 = null;
        String str3;
        Exception e;
        String str4;
        String str5;
        Exception e2;
        Exception e3;
        super.onActivityResult(i, i2, intent);
        String str6 = "3:2";
        int i3 = -1;
        if (i2 == -1 && i == SELECT_PICTURE_FROM_GALLERY) {
            Log.d("hujujhyaa", "onActivityResult: ");
            try {
                StringBuilder sb = new StringBuilder();
                sb.append("SampleCropImage");
                try {
                    try {
                        sb.append(System.currentTimeMillis());
                        sb.append(".png");
                        this.fromFile = Uri.fromFile(new File(getCacheFolder(this), sb.toString()));
                        UCrop.Options options = new UCrop.Options();
                        this.options = options;
                        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
                        this.aspectRatioArr = new AspectRatio[8];
                        this.str3 = "1:1";
                    } catch (Exception e4) {
                        e4.printStackTrace();
                    }
                    try {
                        this.aspectRatioArr[0] = new AspectRatio(this.str3, 1.0f, 1.0f);
                        str4 = this.str3;
                    } catch (Exception e5) {
                        str4 = this.str3;
                        e5.printStackTrace();
                    }
                    try {
                        str3 = "1:1";
                        str6 = str6;
                        str5 = str4;
                        try {
                            this.aspectRatioArr[1] = new AspectRatio(str6, 3.0f, 2.0f);
                            this.aspectRatioArr[2] = new AspectRatio("2:3", 2.0f, 3.0f);
                            this.aspectRatioArr[3] = new AspectRatio("4:3", 4.0f, 3.0f);
                            this.aspectRatioArr[4] = new AspectRatio("3:4", 3.0f, 4.0f);
                            this.aspectRatioArr[5] = new AspectRatio("16:9", 16.0f, 9.0f);
                            try {
                                str = "16:9";
                            } catch (Exception e6) {
                                e3 = e6;
                                str = "16:9";
                            }
                            try {
                                this.aspectRatioArr[6] = new AspectRatio("5:4", 5.0f, 4.0f);
                                this.aspectRatioArr[7] = new AspectRatio("4:5", 4.0f, 5.0f);
                                this.options.setAspectRatioOptions(2, this.aspectRatioArr);
                                UCrop.m79of(intent.getData(), this.fromFile).withOptions(this.options).start(this);
                            } catch (Exception e7) {
                                e3 = e7;
                                try {
                                    e3.printStackTrace();
                                } catch (Exception e8) {
                                    e2 = e8;
                                    try {
                                        e2.printStackTrace();
                                        str2 = str5;
                                        i3 = -1;
                                    } catch (Exception e9) {
                                        e = e9;
                                        e.printStackTrace();
                                        i3 = -1;
                                        str2 = str3;
                                        handleCropResult(intent);
                                        if (i2 == i3) {
                                        }
                                        if (i2 == -1) {
                                        }
                                        if (i2 == 96) {
                                        }
                                    }
                                    handleCropResult(intent);
                                    if (i2 == i3) {
                                    }
                                    if (i2 == -1) {
                                    }
                                    if (i2 == 96) {
                                    }
                                }
                                str2 = str5;
                                i3 = -1;
                                handleCropResult(intent);
                                if (i2 == i3) {
                                }
                                if (i2 == -1) {
                                }
                                if (i2 == 96) {
                                }
                            }
                        } catch (Exception e10) {
                            e2 = e10;
                            str = "16:9";
                        }
                    } catch (Exception e11) {
                        e2 = e11;
                        str3 = "1:1";
                        str = "16:9";
                        str6 = str6;
                        str5 = str4;
                    }
                    str2 = str5;
                    i3 = -1;
                } catch (Exception e12) {
                    e = e12;
                    str3 = "1:1";
                    str = "16:9";
                    str6 = str6;
                    e.printStackTrace();
                    i3 = -1;
                    str2 = str3;
                    handleCropResult(intent);
                    if (i2 == i3) {
                        try {
                            Log.d("ffff", "onActivityResult: " + this.f230f);
                            File filesDir = getFilesDir();
                            Uri fromFile = Uri.fromFile(new File(filesDir, "SampleCropImage" + System.currentTimeMillis() + ".png"));
                            UCrop.Options options2 = new UCrop.Options();
                            options2.setToolbarColor(getResources().getColor(R.color.colorPrimary));
                            options2.setAspectRatioOptions(2, new AspectRatio(str2, 1.0f, 1.0f), new AspectRatio(str6, 3.0f, 2.0f), new AspectRatio("2:3", 2.0f, 3.0f), new AspectRatio("4:3", 4.0f, 3.0f), new AspectRatio("3:4", 3.0f, 4.0f), new AspectRatio(str, 16.0f, 9.0f), new AspectRatio("5:4", 5.0f, 4.0f), new AspectRatio("4:5", 4.0f, 5.0f));
                            UCrop.m79of(FileProvider.getUriForFile(this, getPackageName() + ".provider", this.f230f), fromFile).withOptions(options2).start(this);
                            handleCropResult(intent);
                        } catch (Exception e13) {
                            e13.printStackTrace();
                        }
                    }
                    if (i2 == -1) {
                    }
                    if (i2 == 96) {
                    }
                }
            } catch (Exception e14) {
                e = e14;
                str3 = "1:1";
                str = "16:9";
            }
            handleCropResult(intent);
        } else {
            str = "16:9";
            str2 = "1:1";
        }
        if (i2 == i3 && i == SELECT_PICTURE_FROM_CAMERA) {
            Log.d("ffff", "onActivityResult: " + this.f230f);
            File filesDir2 = getFilesDir();
            Uri fromFile2 = Uri.fromFile(new File(filesDir2, "SampleCropImage" + System.currentTimeMillis() + ".png"));
            UCrop.Options options22 = new UCrop.Options();
            options22.setToolbarColor(getResources().getColor(R.color.colorPrimary));
            options22.setAspectRatioOptions(2, new AspectRatio(str2, 1.0f, 1.0f), new AspectRatio(str6, 3.0f, 2.0f), new AspectRatio("2:3", 2.0f, 3.0f), new AspectRatio("4:3", 4.0f, 3.0f), new AspectRatio("3:4", 3.0f, 4.0f), new AspectRatio(str, 16.0f, 9.0f), new AspectRatio("5:4", 5.0f, 4.0f), new AspectRatio("4:5", 4.0f, 5.0f));
            UCrop.m79of(FileProvider.getUriForFile(this, getPackageName() + ".provider", this.f230f), fromFile2).withOptions(options22).start(this);
            handleCropResult(intent);
        }
        if (i2 == -1 && i != 69) {
            Log.d("yyyyyy", "onActivityResult: ");
        } else if (i2 == 96) {
            UCrop.getError(intent);
        } else {
            handleCropResult(intent);
        }
    }

    private void handleCropResult(Intent intent) {
        Uri uri;
        Log.d("jijijisss", "handleCropResult: ");
        try {
            uri = UCrop.getOutput(intent);
        } catch (Exception e) {
            e.printStackTrace();
            uri = null;
        }
        this.resultUri = uri;
        if (uri != null) {
            this.widht = UCrop.getOutputImageWidth(intent);
            int outputImageHeight = UCrop.getOutputImageHeight(intent);
            this.height = outputImageHeight;
            int i = this.widht;
            int gcd = gcd(i, outputImageHeight);
            this.ratio = "" + (i / gcd) + ":" + (outputImageHeight / gcd) + ":" + i + ":" + outputImageHeight;
            try {
                redirectToCreateCardScreen();
            } catch (Exception e2) {
                while (true) {
                    e2.printStackTrace();
                    return;
                }
            }
        }
    }

    private int gcd(int i, int i2) {
        return i2 == 0 ? i : gcd(i2, i % i2);
    }

    public void redirectToCreateCardScreen() {
        if (this.resultUri != null) {
            Intent intent = new Intent(this, CreateCardActivity.class);
            intent.putExtra("ratio", this.ratio);
            intent.putExtra("loadUserFrame", true);
            intent.putExtra("profile", this.resultUri.toString());
            intent.putExtra("hex", "");
            startActivity(intent);
            return;
        }
        Toast.makeText(this, "Image Not Retrived", 0).show();
    }

    private void findViews() {
        this.btnBack = (ImageView) findViewById(R.id.btn_back);
        this.txtTitle = (TextView) findViewById(R.id.txtTitle);
        this.btnColorPicker = (ImageView) findViewById(R.id.btnColorPicker);
        this.btnGalleryPicker = (ImageView) findViewById(R.id.btnGalleryPicker);
        this.btnTakePicture = (ImageView) findViewById(R.id.btnTakePicture);
        this.txtTitle.setText("Background");
        this.btnColorPicker.setVisibility(0);
        this.txtTitle.setTypeface(setBoldFont());
        this.btnBack.setOnClickListener(this);
        this.btnColorPicker.setOnClickListener(this);
        this.btnGalleryPicker.setOnClickListener(this);
        this.btnTakePicture.setOnClickListener(this);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnColorPicker:
                colorPickerDialog(false);
                return;
            case R.id.btnGalleryPicker:
                requestStorageGalleryPermission();
                return;
            case R.id.btnTakePicture:
                makeStickerDir();
                Intent intent2 = new Intent("android.media.action.IMAGE_CAPTURE");
                this.f230f = new File(getFilesDir(), ".temp.jpg");
                Log.d("aaaddd", "onClick: " + this.f230f);
                intent2.putExtra("output", FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", this.f230f));
                startActivityForResult(intent2, SELECT_PICTURE_FROM_CAMERA);
                return;
            case R.id.btn_back:
                onBackPressed();
                return;
            default:
                return;
        }
    }

    @SuppressLint("MissingPermission")
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void LoadInter_AD() {
        if (BGImageActivity.this.i1 == 1) {
            BGImageActivity.this.requestStorageGalleryPermission();
        } else if (BGImageActivity.this.i1 == 2) {
            BGImageActivity.this.makeStickerDir();
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            BGImageActivity.this.f230f = new File(BGImageActivity.this.getFilesDir(), ".temp.jpg");
            Log.d("aaaddd", "onClick: " + BGImageActivity.this.f230f);
            BGImageActivity bGImageActivity = BGImageActivity.this;
            intent.putExtra("output", FileProvider.getUriForFile(bGImageActivity, BGImageActivity.this.getApplicationContext().getPackageName() + ".provider", BGImageActivity.this.f230f));
            BGImageActivity.this.startActivityForResult(intent, BGImageActivity.SELECT_PICTURE_FROM_CAMERA);
        } else if (BGImageActivity.this.i1 == 3) {
            BGImageActivity.this.colorPickerDialog(false);
        } else if (BGImageActivity.this.i1 == 4) {
            BGImageActivity.this.redirectToCreateCardScreen();
        }
    }


    public void requestStorageGalleryPermission() {
        Dexter.withActivity(this).withPermissions("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.CAMERA").withListener(new MultiplePermissionsListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.13
            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                if (multiplePermissionsReport.areAllPermissionsGranted()) {
                    BGImageActivity.this.makeStickerDir();
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction("android.intent.action.GET_CONTENT");
                    BGImageActivity bGImageActivity = BGImageActivity.this;
                    bGImageActivity.startActivityForResult(Intent.createChooser(intent, bGImageActivity.getString(R.string.select_picture)), BGImageActivity.SELECT_PICTURE_FROM_GALLERY);
                }
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    BGImageActivity.this.showSettingsDialog();
                }
            }

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.12
            @Override // com.karumi.dexter.listener.PermissionRequestErrorListener
            public void onError(DexterError dexterError) {
                Toast.makeText(BGImageActivity.this.getApplicationContext(), "Error occurred! ", 0).show();
            }
        }).onSameThread().check();
    }

    public void colorPickerDialog(boolean z) {
        new AmbilWarnaDialog(this, this.bColor, z, new AmbilWarnaDialog.OnAmbilWarnaListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.14
            @Override // yuku.ambilwarna.AmbilWarnaDialog.OnAmbilWarnaListener
            public void onCancel(AmbilWarnaDialog ambilWarnaDialog) {
            }

            @Override // yuku.ambilwarna.AmbilWarnaDialog.OnAmbilWarnaListener
            public void onOk(AmbilWarnaDialog ambilWarnaDialog, int i) {
                BGImageActivity.this.updateColor(i);
            }
        }).show();
    }

    public void updateColor(int i) {
        Bitmap createBitmap = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888);
        createBitmap.eraseColor(i);
        Log.e(TAG, "updateColor: ");
        try {
            File file = new File(this.preferenceClass.getString(AllConstants.sdcardPath) + "/bg/");
            File file2 = new File(new File(this.preferenceClass.getString(AllConstants.sdcardPath) + "/bg/"), "tempcolor.png");
            if (!file.exists()) {
                file.mkdirs();
            }
            Uri uri = null;
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                try {
                    createBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                    fileOutputStream.close();
                    uri = Uri.fromFile(file2);
                } catch (IOException unused) {
                }
            } catch (IOException e) {
                Log.e("app", e.getMessage());
            }
            if (uri != null) {
                File cacheDir = getCacheDir();
                Uri fromFile = Uri.fromFile(new File(cacheDir, "SampleCropImage" + System.currentTimeMillis() + ".png"));
                UCrop.Options options = new UCrop.Options();
                options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
                options.setAspectRatioOptions(2, new AspectRatio("1:1", 1.0f, 1.0f), new AspectRatio("3:2", 3.0f, 2.0f), new AspectRatio("2:3", 2.0f, 3.0f), new AspectRatio("4:3", 4.0f, 3.0f), new AspectRatio("3:4", 3.0f, 4.0f), new AspectRatio("16:9", 16.0f, 9.0f), new AspectRatio("5:4", 5.0f, 4.0f), new AspectRatio("4:5", 4.0f, 5.0f));
                UCrop.m79of(uri, fromFile).withOptions(options).start(this);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override // com.invitationcardmaker.edigitalcard.listener.GetSnapListener
    public void onSnapFilter(int i, int i2, String str) {
        int i3;
        Uri uri;
        Log.e("cat", "===" + i2);
        if (i2 == 0) {
            Resources resources = getResources();
            i3 = resources.getIdentifier("b" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 1) {
            Resources resources2 = getResources();
            i3 = resources2.getIdentifier("bo" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 2) {
            Resources resources3 = getResources();
            i3 = resources3.getIdentifier("br" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 3) {
            Resources resources4 = getResources();
            i3 = resources4.getIdentifier("c" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 4) {
            Resources resources5 = getResources();
            i3 = resources5.getIdentifier("ch" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 5) {
            Resources resources6 = getResources();
            i3 = resources6.getIdentifier("d" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 6) {
            Resources resources7 = getResources();
            i3 = resources7.getIdentifier("f" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 7) {
            Resources resources8 = getResources();
            i3 = resources8.getIdentifier("fl" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 8) {
            Resources resources9 = getResources();
            i3 = resources9.getIdentifier("g" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 9) {
            Resources resources10 = getResources();
            i3 = resources10.getIdentifier("h" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 10) {
            Resources resources11 = getResources();
            i3 = resources11.getIdentifier("l" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 11) {
            Resources resources12 = getResources();
            i3 = resources12.getIdentifier("w" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 12) {
            Resources resources13 = getResources();
            i3 = resources13.getIdentifier("wo" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 13) {
            Resources resources14 = getResources();
            i3 = resources14.getIdentifier("f" + (i + 1), "drawable", getPackageName());
        } else if (i2 == 14) {
            Resources resources15 = getResources();
            i3 = resources15.getIdentifier("m" + (i + 1), "drawable", getPackageName());
        } else {
            i3 = 1;
        }
        Log.e("position", "===" + i);
        try {
            if (str.equals("null")) {
                Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), i3);
                File file = new File(this.preferenceClass.getString(AllConstants.sdcardPath) + "/bg" + i2 + "/");
                File file2 = new File(file, String.valueOf(i));
                uri = null;
                if (file2.exists()) {
                    uri = Uri.fromFile(file2);
                    Log.e(ImagesContract.URL, "===" + uri);
                } else {
                    try {
                        if (!file.exists()) {
                            file.mkdirs();
                        }
                        FileOutputStream fileOutputStream = new FileOutputStream(file2);
                        try {
                            decodeResource.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                            fileOutputStream.close();
                            uri = Uri.fromFile(file2);
                        } catch (IOException unused) {
                        }
                    } catch (IOException e) {
                        Log.e("app", e.getMessage());
                    }
                }
            } else {
                uri = Uri.fromFile(new File(new File(str).getPath()));
            }
            if (uri == null) {
                File cacheDir = getCacheDir();
                Uri fromFile = Uri.fromFile(new File(cacheDir, "SampleCropImage" + System.currentTimeMillis() + ".png"));
                UCrop.Options options = new UCrop.Options();
                options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
                options.setAspectRatioOptions(1, new AspectRatio("1:1", 1.0f, 1.0f), new AspectRatio("3:2", 3.0f, 2.0f), new AspectRatio("2:3", 2.0f, 3.0f), new AspectRatio("4:3", 4.0f, 3.0f), new AspectRatio("3:4", 3.0f, 4.0f), new AspectRatio("16:9", 16.0f, 9.0f), new AspectRatio("5:4", 5.0f, 4.0f), new AspectRatio("4:5", 4.0f, 5.0f));
                UCrop.m79of(uri, fromFile).withOptions(options).start(this);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override // com.invitationcardmaker.edigitalcard.main.GetSnapListenerS
    public void onSnapFilter(int i, int i2, String str, String str2) {
        requestStorageSnapPermission(i, i2, str, str2);
    }

    public void makeStickerDir() {
        this.preferenceClass = new PreferenceClass(this);
        File file = new File(Configure.GetFileDir(this).getPath() + "/.Invitation Stickers/sticker");
        if (!file.exists()) {
            file.mkdirs();
        }
        this.preferenceClass.putString(AllConstants.sdcardPath, file.getPath());
        Log.e(TAG, "onCreate: " + AllConstants.sdcardPath);
    }

    private void requestStorageSnapPermission(final int i, final int i2, final String str, String str2) {
        Dexter.withActivity(this).withPermissions("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE").withListener(new MultiplePermissionsListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.16
            Uri fromFile;

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                if (multiplePermissionsReport.areAllPermissionsGranted()) {
                    BGImageActivity.this.makeStickerDir();
                    Uri uri = null;
                    try {
                        if (str.equals("null")) {
                            Bitmap decodeResource = BitmapFactory.decodeResource(BGImageActivity.this.getResources(), 1);
                            File file = new File(BGImageActivity.this.preferenceClass.getString(AllConstants.sdcardPath) + "/bg" + i2 + "/");
                            File file2 = new File(file, String.valueOf(i));
                            if (file2.exists()) {
                                this.fromFile = Uri.fromFile(file2);
                            } else {
                                try {
                                    if (!file.exists()) {
                                        file.mkdirs();
                                    }
                                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                                    try {
                                        decodeResource.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                                        fileOutputStream.close();
                                        this.fromFile = Uri.fromFile(file2);
                                    } catch (IOException unused) {
                                        multiplePermissionsReport.isAnyPermissionPermanentlyDenied();
                                    }
                                } catch (IOException unused2) {
                                    multiplePermissionsReport.isAnyPermissionPermanentlyDenied();
                                }
                            }
                            uri = this.fromFile;
                        } else {
                            BGImageActivity.this.onGetPosition(str);
                        }
                        if (uri != null) {
                            File cacheDir = BGImageActivity.this.getCacheDir();
                            Uri fromFile = Uri.fromFile(new File(cacheDir, "SampleCropImage" + System.currentTimeMillis() + ".png"));
                            UCrop.Options options = new UCrop.Options();
                            options.setToolbarColor(BGImageActivity.this.getResources().getColor(R.color.colorPrimary));
                            options.setAspectRatioOptions(2, new AspectRatio("1:1", 1.0f, 1.0f), new AspectRatio("3:2", 3.0f, 2.0f), new AspectRatio("2:3", 2.0f, 3.0f), new AspectRatio("4:3", 4.0f, 3.0f), new AspectRatio("3:4", 3.0f, 4.0f), new AspectRatio("16:9", 16.0f, 9.0f), new AspectRatio("5:4", 5.0f, 4.0f), new AspectRatio("4:5", 4.0f, 5.0f));
                            UCrop.m79of(uri, fromFile).withOptions(options).start(BGImageActivity.this);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    BGImageActivity.this.showSettingsDialog();
                }
            }

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.15
            @Override // com.karumi.dexter.listener.PermissionRequestErrorListener
            public void onError(DexterError dexterError) {
                Toast.makeText(BGImageActivity.this.getApplicationContext(), "Error occurred! ", 0).show();
            }
        }).onSameThread().check();
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.17
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                BGImageActivity.this.openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() { // from class: com.invitationcardmaker.edigitalcard.main.BGImageActivity.18
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void openSettings() {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivityForResult(intent, 101);
    }
}
