package com.invitationcardmaker.edigitalcard.main;

/* loaded from: classes2.dex */
public interface GetColorListener {
    void onColor(int i, String str, int i2);
}
