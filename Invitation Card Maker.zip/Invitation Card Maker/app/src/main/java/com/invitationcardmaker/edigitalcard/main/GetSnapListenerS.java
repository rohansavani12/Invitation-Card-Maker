package com.invitationcardmaker.edigitalcard.main;

/* loaded from: classes2.dex */
public interface GetSnapListenerS {
    void onSnapFilter(int i, int i2, String str, String str2);
}
