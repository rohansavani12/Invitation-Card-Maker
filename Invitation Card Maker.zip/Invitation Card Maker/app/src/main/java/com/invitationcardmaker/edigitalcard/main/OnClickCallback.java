package com.invitationcardmaker.edigitalcard.main;

import android.app.Activity;
import com.invitationcardmaker.edigitalcard.pojoClass.BackgroundImage;
import java.util.ArrayList;

/* loaded from: classes2.dex */
public interface OnClickCallback<T, P, A, V, Q> {
    void onClickCallBack(ArrayList<String> arrayList, ArrayList<BackgroundImage> arrayList2, String str, Activity activity, String str2);
}
