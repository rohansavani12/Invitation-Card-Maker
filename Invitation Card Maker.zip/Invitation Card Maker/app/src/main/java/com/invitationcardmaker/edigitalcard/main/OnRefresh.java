package com.invitationcardmaker.edigitalcard.main;

/* loaded from: classes2.dex */
public interface OnRefresh {
    void onRefresh();
}
