package com.invitationcardmaker.edigitalcard.main;

/* loaded from: classes2.dex */
public interface OnSetImageSticker {
    void ongetSticker();
}
