package com.invitationcardmaker.edigitalcard.main;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;
import com.invitationcardmaker.edigitalcard.InvitationApplication;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_activity.Unitech_BaseActivity;
import com.invitationcardmaker.edigitalcard.Unitech_activity.MainActivity;
import com.invitationcardmaker.edigitalcard.network.NetworkConnectivityReceiver;
import com.invitationcardmaker.edigitalcard.utils.PreferenceClass;
import java.io.File;
import java.io.FileOutputStream;

public class ShareImageActivity extends Unitech_BaseActivity implements View.OnClickListener {
    private static final String TAG = "ShareImageActivity";
    public static File pictureFile;
    private int REQUEST_FOR_GOOGLE_PLUS = 0;
    public PreferenceClass appPreference;
    private RelativeLayout btnBack;
    private ImageView btnMoreApp;
    private ImageView btnShareFacebook;
    private ImageView btnShareGooglePlus;
    private ImageView btnShareHike;
    private ImageView btnShareIntagram;
    private ImageView btnShareMore;
    private ImageView btnShareMoreImage;
    private ImageView btnShareTwitter;
    private ImageView btnShareWhatsapp;
    private ImageView btnSharewMessanger;
    FrameLayout frameBanner;
    public ImageView imageView;
    private String oldpath;
    public Uri phototUri = null;
    ProgressDialog progress;
    private RelativeLayout removeWaterMark;
    private TextView txtToolbar;
    private TextView txt_remove;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, com.invitationcardmaker.edigitalcard.activity.BaseActivity
    public void onCreate(Bundle bundle) {
        getWindow().setFlags(1024, 1024);
        super.onCreate(bundle);
        setContentView(R.layout.unitech_activity_share_image);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.layoutBannerAd);
        this.frameBanner = frameLayout;
        PreferenceClass preferenceClass = new PreferenceClass(this);
        this.appPreference = preferenceClass;
        if (!preferenceClass.getBoolean("isAdsDisabled", false) && NetworkConnectivityReceiver.isConnected() && InvitationApplication.advertise != null) {
            InvitationApplication.advertise.getFlag().equalsIgnoreCase("1");
        }
        findView();
        if (getIntent().getExtras().getString("way").equals("Gallery")) {
            this.removeWaterMark.setVisibility(8);
        }
        if (this.appPreference.getInt(AllConstants.isRated, 0) == 0) {
//            showRateUsDailog();
        }
        initUI();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    @SuppressLint("MissingPermission")
    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    private void findView() {
        this.txt_remove = (TextView) findViewById(R.id.txt_remove);
        this.removeWaterMark = (RelativeLayout) findViewById(R.id.btn_remowatermark);
        this.btnBack = (RelativeLayout) findViewById(R.id.btn_back);
        this.txtToolbar = (TextView) findViewById(R.id.txt_toolbar);
        this.btnShareMore = (ImageView) findViewById(R.id.btnShareMore);
        this.btnMoreApp = (ImageView) findViewById(R.id.btnMoreApp);
        this.btnShareFacebook = (ImageView) findViewById(R.id.btnShareFacebook);
        this.btnShareIntagram = (ImageView) findViewById(R.id.btnShareIntagram);
        this.btnShareWhatsapp = (ImageView) findViewById(R.id.btnShareWhatsapp);
        this.btnShareGooglePlus = (ImageView) findViewById(R.id.btnShareGooglePlus);
        this.btnSharewMessanger = (ImageView) findViewById(R.id.btnSharewMessanger);
        this.btnShareTwitter = (ImageView) findViewById(R.id.btnShareTwitter);
        this.btnShareHike = (ImageView) findViewById(R.id.btnShareHike);
        this.btnShareMoreImage = (ImageView) findViewById(R.id.btnShareMoreImage);
        this.btnBack.setOnClickListener(this);
        this.btnShareMore.setOnClickListener(this);
        this.btnMoreApp.setOnClickListener(this);
        this.btnShareFacebook.setOnClickListener(this);
        this.btnShareIntagram.setOnClickListener(this);
        this.btnShareWhatsapp.setOnClickListener(this);
        this.btnShareGooglePlus.setOnClickListener(this);
        this.btnSharewMessanger.setOnClickListener(this);
        this.btnShareTwitter.setOnClickListener(this);
        this.btnShareHike.setOnClickListener(this);
        this.btnShareMoreImage.setOnClickListener(this);
        this.removeWaterMark.setOnClickListener(this);
        this.txt_remove.setTypeface(setBoldFont());
        this.txtToolbar.setTypeface(setBoldFont());
    }

    public void initUI() {
        this.imageView = (ImageView) findViewById(R.id.image);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String string = extras.getString("uri");
            this.oldpath = string;
            if (string.equals("")) {
                Toast.makeText(this, getResources().getString(R.string.picUpImg), 0).show();
                finish();
            } else {
                this.phototUri = Uri.parse(this.oldpath);
            }
        } else {
            Toast.makeText(this, getResources().getString(R.string.picUpImg), 0).show();
            finish();
        }
        try {
            File file = new File(this.phototUri.getPath());
            pictureFile = file;
            this.imageView.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath(), new BitmapFactory.Options()));
        } catch (Exception e) {
            e.printStackTrace();
            try {
                this.imageView.setImageURI(this.phototUri);
            } catch (OutOfMemoryError e2) {
                e2.printStackTrace();
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error), 0).show();
                finish();
            }
        }
        if (this.appPreference.getBoolean("removeWatermark", false)) {
            this.removeWaterMark.setVisibility(8);
        }
    }

    @Override // androidx.activity.ComponentActivity, androidx.fragment.app.FragmentActivity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btnMoreApp) {
//            moreApp("https://play.google.com/store/apps/details?id=" + getPackageName());
        } else if (id == R.id.btn_back) {
            finish();
        } else if (id != R.id.btn_remowatermark) {
            switch (id) {
                case R.id.btnShareFacebook:
                    shareToFacebook(pictureFile.getPath());
                    return;
                case R.id.btnShareGooglePlus:
                    sendToGooglePlus(pictureFile.getPath());
                    return;
                case R.id.btnShareHike:
                    shareToHike(pictureFile.getPath());
                    return;
                case R.id.btnShareIntagram:
                    shareToInstagram(pictureFile.getPath());
                    return;
                case R.id.btnShareMore:
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    return;
                case R.id.btnShareMoreImage:
                    shareImage(pictureFile.getPath());
                    return;
                case R.id.btnShareTwitter:
                    shareToTwitter(pictureFile.getPath());
                    return;
                case R.id.btnShareWhatsapp:
                    sendToWhatsaApp(pictureFile.getPath());
                    return;
                case R.id.btnSharewMessanger:
                    shareToMessanger(pictureFile.getPath());
                    return;
                default:
                    return;
            }
        } else {
            showInAppDailog();
        }
    }
    private void showInAppDailog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.in_app);
        Button button = (Button) dialog.findViewById(R.id.btnBuyRate);
        Button button2 = (Button) dialog.findViewById(R.id.btnNo);
        ((TextView) dialog.findViewById(R.id.txtTitle)).setTypeface(setBoldFont());
        ((TextView) dialog.findViewById(R.id.txtDes)).setTypeface(setBoldFont());
        ((TextView) dialog.findViewById(R.id.txtDescription)).setTypeface(setNormalFont());
        button.setTypeface(setBoldFont());
        button2.setTypeface(setBoldFont());
        button.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.ShareImageActivity.AnonymousClass7 */

            public void onClick(View view) {
                    ShareImageActivity.this.saveBitmap();
                    dialog.dismiss();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.ShareImageActivity.AnonymousClass8 */

            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }



    @Override // androidx.activity.ComponentActivity
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override // androidx.fragment.app.FragmentActivity
    public void onResume() {
        super.onResume();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onDestroy() {
        super.onDestroy();
    }

    public void sendToWhatsaApp(String str) {
        if (getApplicationContext().getPackageManager().getLaunchIntentForPackage("com.whatsapp") != null) {
            try {
                Uri uriForFile = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str));
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.STREAM", uriForFile);
                intent.setPackage("com.whatsapp");
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "WhatsApp not installed", 0).show();
        }
    }

    public void sendToGooglePlus(String str) {
        if (getApplicationContext().getPackageManager().getLaunchIntentForPackage("com.google.android.apps.plus") != null) {
            try {
                ShareCompat.IntentBuilder type = ShareCompat.IntentBuilder.from(this).setType("image/jpeg");
                startActivityForResult(type.setStream(FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str))).getIntent().setPackage("com.google.android.apps.plus"), this.REQUEST_FOR_GOOGLE_PLUS);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Google Plus not installed", 0).show();
        }
    }

    public void shareToHike(String str) {
        if (getApplicationContext().getPackageManager().getLaunchIntentForPackage("com.bsb.hike") != null) {
            try {
                Uri uriForFile = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str));
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.STREAM", uriForFile);
                intent.setPackage("com.bsb.hike");
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Hike not installed", 0).show();
        }
    }

    private void shareToTwitter(String str) {
        try {
            if (getApplicationContext().getPackageManager().getLaunchIntentForPackage("com.twitter.android") != null) {
                try {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str)));
                    intent.setType("image/*");
                    for (ResolveInfo resolveInfo : getPackageManager().queryIntentActivities(intent, 65536)) {
                        if (resolveInfo.activityInfo.name.contains("twitter")) {
                            intent.setClassName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
                            startActivity(intent);
                            return;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(this, "Twitter not installed", 0).show();
            }
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(getApplicationContext(), "You don't seem to have twitter installed on this device", 0).show();
        }
    }

    public void shareToFacebook(String str) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setPackage("com.facebook.katana");
        if (getApplicationContext().getPackageManager().getLaunchIntentForPackage("com.facebook.katana") != null) {
            try {
                intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str)));
                intent.setType("image/*");
                intent.addFlags(1);
                startActivity(Intent.createChooser(intent, "Share Gif."));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Facebook not installed", 0).show();
        }
    }

    public void shareToMessanger(String str) {
        if (getPackageManager().getLaunchIntentForPackage("com.facebook.orca") != null) {
            try {
                MediaScannerConnection.scanFile(getApplicationContext(), new String[]{str}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    /* class com.invitationcardmaker.edigitalcard.main.ShareImageActivity.AnonymousClass9 */

                    public void onScanCompleted(String str, Uri uri) {
                        Intent intent = new Intent("android.intent.action.SEND");
                        intent.setType("image/gif");
                        intent.setPackage("com.facebook.orca");
                        intent.putExtra("android.intent.extra.STREAM", uri);
                        intent.addFlags(524288);
                        ShareImageActivity.this.startActivity(Intent.createChooser(intent, "Test"));
                    }
                });
            } catch (ActivityNotFoundException unused) {
                Toast.makeText(getApplicationContext(), "You don't seem to have twitter installed on this device", 0).show();
            }
        } else {
            Toast.makeText(this, "Facebook Messanger not installed", 0).show();
        }
    }

    public void shareToInstagram(String str) {
        if (getApplicationContext().getPackageManager().getLaunchIntentForPackage("com.instagram.android") != null) {
            try {
                Uri uriForFile = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str));
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("image/*");
                new File(str);
                intent.putExtra("android.intent.extra.STREAM", uriForFile);
                intent.setPackage("com.instagram.android");
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Instagram not installed", 0).show();
        }
    }

    public void shareImage(String str) {
        try {
            Uri uriForFile = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", new File(str));
            Intent intent = new Intent("android.intent.action.SEND");
            intent.addFlags(524288);
            intent.setType("image/*");
            intent.putExtra("android.intent.extra.STREAM", uriForFile);
            startActivity(Intent.createChooser(intent, "Share Image Using"));
        } catch (Exception e) {
            Log.e(TAG, "shareImage: " + e);
        }
    }

    public void saveBitmap() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.plzwait));
        progressDialog.setCancelable(false);
        try {
            progressDialog.show();
        } catch (Exception unused) {
        }
        new Thread(new Runnable() {
            /* class com.invitationcardmaker.edigitalcard.main.ShareImageActivity.AnonymousClass10 */

            public void run() {
                ShareImageActivity.pictureFile = new File(ShareImageActivity.this.phototUri.getPath());
                try {
                    if (!ShareImageActivity.pictureFile.exists()) {
                        ShareImageActivity.pictureFile.createNewFile();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(ShareImageActivity.pictureFile);
                    CreateCardActivity.withoutWatermark.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    MediaScannerConnection.scanFile(ShareImageActivity.this, new String[]{ShareImageActivity.pictureFile.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                        /* class com.invitationcardmaker.edigitalcard.main.ShareImageActivity.AnonymousClass10.AnonymousClass1 */

                        public void onScanCompleted(String str, Uri uri) {
                            Log.i("ExternalStorage", "Scanned " + str + ":");
                            StringBuilder sb = new StringBuilder();
                            sb.append("-> uri=");
                            sb.append(uri);
                            Log.i("ExternalStorage", sb.toString());
                        }
                    });
                    ShareImageActivity shareImageActivity = ShareImageActivity.this;
                    shareImageActivity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", FileProvider.getUriForFile(shareImageActivity, ShareImageActivity.this.getApplicationContext().getPackageName() + ".provider", ShareImageActivity.pictureFile)));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
                progressDialog.dismiss();
            }
        }).start();
        progressDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            /* class com.invitationcardmaker.edigitalcard.main.ShareImageActivity.AnonymousClass11 */

            public void onDismiss(DialogInterface dialogInterface) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                options.inSampleSize = 2;
                ShareImageActivity.this.imageView.setImageBitmap(BitmapFactory.decodeFile(ShareImageActivity.pictureFile.getAbsolutePath(), options));
            }
        });
    }
}