package com.invitationcardmaker.edigitalcard.main;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import com.invitationcardmaker.edigitalcard.InvitationApplication;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_activity.Unitech_BaseActivity;
import com.invitationcardmaker.edigitalcard.adapter.WorkPosterAdapter;
import com.invitationcardmaker.edigitalcard.listener.OnClickCallback;
import com.invitationcardmaker.edigitalcard.network.NetworkConnectivityReceiver;
import com.invitationcardmaker.edigitalcard.utility.ImageUtils;
import com.invitationcardmaker.edigitalcard.utils.PreferenceClass;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class WorkCardActivity extends Unitech_BaseActivity {
    private static final String TAG = "MyPosterActivity";
    public static File[] listFile;
    private RelativeLayout btn_back;
    public Context context;
    public int count = 0;
    FrameLayout frameBanner;
    public WorkPosterAdapter imageAdapter;
    public GridView imagegrid;
    private TextView no_image;
    private PreferenceClass preferenceClass;
    public RelativeLayout rel_text;
    public int screenWidth;
    public int spostion;
    private TextView txtTitle;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, com.invitationcardmaker.edigitalcard.activity.BaseActivity
    public void onCreate(Bundle bundle) {
        getWindow().setFlags(1024, 1024);
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        setContentView(R.layout.unitech_activity_work_card);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.layoutBannerAd);
        this.frameBanner = frameLayout;
        setMyFontBold((ViewGroup) findViewById(16908290));
        this.preferenceClass = new PreferenceClass(this);
        if (NetworkConnectivityReceiver.isConnected() && !this.preferenceClass.getBoolean("isAdsDisabled", false) && InvitationApplication.advertise != null) {
            InvitationApplication.advertise.getFlag().equalsIgnoreCase("1");
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.screenWidth = displayMetrics.widthPixels - ImageUtils.dpToPx((Context) this, 10);
        this.no_image = (TextView) findViewById(R.id.no_image);
        this.rel_text = (RelativeLayout) findViewById(R.id.rel_text);
        this.txtTitle = (TextView) findViewById(R.id.txtTitle);
        this.btn_back = (RelativeLayout) findViewById(R.id.btn_back);
        this.txtTitle.setTypeface(setBoldFont());
        this.no_image.setTypeface(setBoldFont());
        this.btn_back.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass1 */

            public void onClick(View view) {
                WorkCardActivity.this.onBackPressed();
            }
        });
        this.imagegrid = (GridView) findViewById(R.id.gridView);
        requestStoragePermission();
        this.imagegrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass2 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                WorkCardActivity.this.spostion = i;
                Intent intent = new Intent(WorkCardActivity.this, ShareImageActivity.class);
                intent.putExtra("uri", WorkCardActivity.listFile[i].getAbsolutePath());
                intent.putExtra("way", "Gallery");
                WorkCardActivity.this.startActivity(intent);
            }
        });
    }


    private void requestStoragePermission() {
        Dexter.withActivity(this).withPermissions("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE").withListener(new MultiplePermissionsListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass5 */

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                if (multiplePermissionsReport.areAllPermissionsGranted()) {
                    WorkCardActivity.this.getImageAndView();
                }
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    WorkCardActivity.this.showSettingsDialog();
                }
            }

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass4 */

            @Override // com.karumi.dexter.listener.PermissionRequestErrorListener
            public void onError(DexterError dexterError) {
                Toast.makeText(WorkCardActivity.this.getApplicationContext(), "Error occurred! ", 0).show();
            }
        }).onSameThread().check();
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass6 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                WorkCardActivity.this.openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass7 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void openSettings() {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivityForResult(intent, 101);
    }

    public void getImageAndView() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.plzwait));
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Thread(new Runnable() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass8 */

            public void run() {
                try {
                    WorkCardActivity.this.getFromSdcard();
                    WorkCardActivity workCardActivity = WorkCardActivity.this;
                    workCardActivity.context = workCardActivity;
                    if (WorkCardActivity.listFile != null) {
                        WorkCardActivity.this.imageAdapter = new WorkPosterAdapter(WorkCardActivity.this.getApplicationContext(), WorkCardActivity.listFile, WorkCardActivity.this.screenWidth);
                        WorkCardActivity.this.imageAdapter.setItemClickCallback(new OnClickCallback<ArrayList<String>, Integer, String, Context>() {
                            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass8.AnonymousClass1 */

                            public void onClickCallBack(ArrayList<String> arrayList, Integer num, String str, Context context) {
                                WorkCardActivity.this.showOptionsDialog(num.intValue());
                            }
                        });
                        Thread.sleep(1000);
                    }
                } catch (Exception e) {
                    Log.e(WorkCardActivity.TAG, "run: " + e);
                }
                progressDialog.dismiss();
            }
        }).start();
        progressDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass9 */

            public void onDismiss(DialogInterface dialogInterface) {
                WorkCardActivity.this.imagegrid.setAdapter((ListAdapter) WorkCardActivity.this.imageAdapter);
                if (WorkCardActivity.this.count == 0) {
                    WorkCardActivity.this.rel_text.setVisibility(0);
                } else {
                    WorkCardActivity.this.rel_text.setVisibility(8);
                }
            }
        });
    }

    public void showOptionsDialog(final int i) {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.unitech_delete_popup);
        dialog.setCancelable(false);
        Button button = (Button) dialog.findViewById(R.id.btnDelete);
        Button button2 = (Button) dialog.findViewById(R.id.btnCancel);
        ((TextView) dialog.findViewById(R.id.txtTitle)).setTypeface(setBoldFont());
        ((TextView) dialog.findViewById(R.id.txtDescription)).setTypeface(setNormalFont());
        button.setTypeface(setBoldFont());
        button2.setTypeface(setBoldFont());
        button.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass10 */

            public void onClick(View view) {
                if (WorkCardActivity.this.deleteFile(Uri.parse(WorkCardActivity.listFile[i].getAbsolutePath()))) {
                    WorkCardActivity.listFile = null;
                    WorkCardActivity.this.getImageAndView();
                    dialog.dismiss();
                }
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass11 */

            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public boolean deleteFile(Uri uri) {
        boolean z = false;
        try {
            File file = new File(uri.getPath());
            z = file.delete();
            if (file.exists()) {
                try {
                    z = file.getCanonicalFile().delete();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (file.exists()) {
                    z = getApplicationContext().deleteFile(file.getName());
                }
            }
            sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", file)));
        } catch (Exception unused) {
            Log.e(TAG, "deleteFile: ");
        }
        return z;
    }

    public void getFromSdcard() {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/Invitation Design");
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            listFile = listFiles;
            this.count = listFiles.length;
            Arrays.sort(listFiles, new Comparator<File>() {
                /* class com.invitationcardmaker.edigitalcard.main.WorkCardActivity.AnonymousClass12 */

                public int compare(File file, File file2) {
                    long j;
                    long j2;
                    if (Build.VERSION.SDK_INT >= 19) {
                        j2 = file2.lastModified();
                        j = file.lastModified();
                    } else {
                        j2 = file2.lastModified();
                        j = file.lastModified();
                    }
                    int i = (j2 > j ? 1 : (j2 == j ? 0 : -1));
                    if (i > 0) {
                        return 1;
                    }
                    return i == 0 ? 0 : -1;
                }
            });
        }
    }

    @Override // androidx.fragment.app.FragmentActivity
    public void onResume() {
        super.onResume();
    }

    @Override // androidx.activity.ComponentActivity
    public void onBackPressed() {
        super.onBackPressed();
    }
}