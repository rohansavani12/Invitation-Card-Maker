package com.invitationcardmaker.edigitalcard.main;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.invitationcardmaker.edigitalcard.InvitationApplication;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.Unitech_activity.Unitech_BaseActivity;
import com.invitationcardmaker.edigitalcard.adapter.DesignPosterAdapter;
import com.invitationcardmaker.edigitalcard.handler.DatabaseHandler;
import com.invitationcardmaker.edigitalcard.handler.TemplateInfo;
import com.invitationcardmaker.edigitalcard.network.NetworkConnectivityReceiver;
import com.invitationcardmaker.edigitalcard.utility.ImageUtils;
import com.invitationcardmaker.edigitalcard.utils.Config;
import com.invitationcardmaker.edigitalcard.utils.PreferenceClass;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import java.util.ArrayList;
import java.util.List;

public class WorkDesignActivity extends Unitech_BaseActivity {
    private Animation animSlideDown;
    private Animation animSlideUp;
    String catName = "MY_TEMP";
    public DesignPosterAdapter designPosterAdapter;
    FrameLayout frameBanner;
    public GridView gridView;
    int heightItemGrid = 50;
    private RelativeLayout imagBack;
    LordDataOperationAsync loadDataAsync = null;
    LinearLayout lv_buy_pro;
    private PreferenceClass preferenceClass;
    ProgressBar progress_bar;
    public int spoisiton;
    public ArrayList<TemplateInfo> templateList = new ArrayList<>();
    Typeface ttf;
    private TextView txtTitle;
    TextView txt_dialog;
    int widthItemGrid = 50;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.fragment.app.FragmentActivity, com.invitationcardmaker.edigitalcard.activity.BaseActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        requestWindowFeature(1);
        setContentView(R.layout.unitech_activity_my_design);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.layoutBannerAd);
        this.frameBanner = frameLayout;
        Config.SaveInt("flow", 1, this);
        this.preferenceClass = new PreferenceClass(this);
        if (NetworkConnectivityReceiver.isConnected() && !this.preferenceClass.getBoolean("isAdsDisabled", false) && InvitationApplication.advertise != null) {
            InvitationApplication.advertise.getFlag().equalsIgnoreCase("1");
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.widthItemGrid = ((int) ((float) (displayMetrics.widthPixels - ImageUtils.dpToPx((Context) this, 10)))) / 2;
        this.heightItemGrid = ((int) ((float) (displayMetrics.heightPixels - ImageUtils.dpToPx((Context) this, 10)))) / 2;
        TextView textView = (TextView) findViewById(R.id.txtTitle);
        this.txtTitle = textView;
        textView.setTypeface(setBoldFont());
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.btn_back);
        this.imagBack = relativeLayout;
        relativeLayout.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkDesignActivity.AnonymousClass1 */

            public void onClick(View view) {
                WorkDesignActivity.this.onBackPressed();
            }
        });
        this.gridView = (GridView) findViewById(R.id.gridview);
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progress_bar);
        this.progress_bar = progressBar;
        progressBar.setVisibility(8);
        this.txt_dialog = (TextView) findViewById(R.id.txt_dialog);
        this.animSlideUp = AllConstants.getAnimUp(this);
        this.animSlideDown = AllConstants.getAnimDown(this);
        requestStoragePermission();
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkDesignActivity.AnonymousClass2 */

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                WorkDesignActivity.this.spoisiton = i;
                Intent intent = new Intent(WorkDesignActivity.this, CreateCardActivity.class);
                intent.putExtra("position", i);
                intent.putExtra("loadUserFrame", false);
                intent.putExtra("Temp_Type", WorkDesignActivity.this.catName);
                WorkDesignActivity.this.startActivity(intent);
            }
        });
    }


    private void requestStoragePermission() {
        Dexter.withActivity(this).withPermissions("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE").withListener(new MultiplePermissionsListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkDesignActivity.AnonymousClass5 */

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                if (multiplePermissionsReport.areAllPermissionsGranted()) {
                    WorkDesignActivity.this.loadDataAsync = new LordDataOperationAsync();
                    WorkDesignActivity.this.loadDataAsync.execute("");
                }
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    WorkDesignActivity.this.showSettingsDialog();
                }
            }

            @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkDesignActivity.AnonymousClass4 */

            @Override // com.karumi.dexter.listener.PermissionRequestErrorListener
            public void onError(DexterError dexterError) {
                Toast.makeText(WorkDesignActivity.this.getApplicationContext(), "Error occurred! ", 0).show();
            }
        }).onSameThread().check();
    }

    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkDesignActivity.AnonymousClass6 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                WorkDesignActivity.this.openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.main.WorkDesignActivity.AnonymousClass7 */

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    public void openSettings() {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivityForResult(intent, 101);
    }

    public class LordDataOperationAsync extends AsyncTask<String, Void, String> {
        public LordDataOperationAsync() {
        }

        public void onPreExecute() {
            WorkDesignActivity.this.progress_bar.setVisibility(0);
        }

        public String doInBackground(String... strArr) {
            try {
                WorkDesignActivity.this.templateList.clear();
                DatabaseHandler dbHandler = DatabaseHandler.getDbHandler(WorkDesignActivity.this);
                if (WorkDesignActivity.this.catName.equals("MY_TEMP")) {
                    WorkDesignActivity.this.templateList = dbHandler.getTemplateListDes("USER");
                }
                dbHandler.close();
                return "yes";
            } catch (NullPointerException unused) {
                return "yes";
            }
        }

        public void onPostExecute(String str) {
            try {
                WorkDesignActivity.this.progress_bar.setVisibility(8);
                if (WorkDesignActivity.this.templateList.size() != 0) {
                    WorkDesignActivity workDesignActivity = WorkDesignActivity.this;
                    workDesignActivity.designPosterAdapter = new DesignPosterAdapter(workDesignActivity, workDesignActivity.templateList, WorkDesignActivity.this.catName, WorkDesignActivity.this.widthItemGrid);
                    WorkDesignActivity.this.gridView.setAdapter((ListAdapter) WorkDesignActivity.this.designPosterAdapter);
                }
                if (WorkDesignActivity.this.catName.equals("MY_TEMP")) {
                    if (WorkDesignActivity.this.templateList.size() == 0) {
                        WorkDesignActivity.this.txt_dialog.setText(WorkDesignActivity.this.getResources().getString(R.string.NoDesigns));
                    } else if (WorkDesignActivity.this.templateList.size() <= 4) {
                        WorkDesignActivity.this.txt_dialog.setText(WorkDesignActivity.this.getResources().getString(R.string.DesignOptionsInstruction));
                    }
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }
    }
}