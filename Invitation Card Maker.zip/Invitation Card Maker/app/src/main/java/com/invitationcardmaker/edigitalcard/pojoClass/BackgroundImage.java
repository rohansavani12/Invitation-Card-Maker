package com.invitationcardmaker.edigitalcard.pojoClass;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes2.dex */
public class BackgroundImage implements Parcelable {
    public static final Creator<BackgroundImage> CREATOR = new Creator<BackgroundImage>() { // from class: com.invitationcardmaker.edigitalcard.pojoClass.BackgroundImage.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BackgroundImage createFromParcel(Parcel parcel) {
            return new BackgroundImage(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BackgroundImage[] newArray(int i) {
            return new BackgroundImage[i];
        }
    };
    String category_name;
    int f234id;
    String image_url;
    String thumb_url;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BackgroundImage(int i, String str, String str2, String str3) {
        this.f234id = i;
        this.thumb_url = str;
        this.image_url = str2;
        this.category_name = str3;
    }

    protected BackgroundImage(Parcel parcel) {
        this.f234id = parcel.readInt();
        this.category_name = parcel.readString();
        this.thumb_url = parcel.readString();
        this.image_url = parcel.readString();
    }

    public int getId() {
        return this.f234id;
    }

    public String getCategory_name() {
        return this.category_name;
    }

    public void setCategory_name(String str) {
        this.category_name = str;
    }

    public void setId(int i) {
        this.f234id = i;
    }

    public String getThumb_url() {
        return this.thumb_url;
    }

    public void setThumb_url(String str) {
        this.thumb_url = str;
    }

    public String getImage_url() {
        return this.image_url;
    }

    public void setImage_url(String str) {
        this.image_url = str;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f234id);
        parcel.writeString(this.category_name);
        parcel.writeString(this.thumb_url);
        parcel.writeString(this.image_url);
    }
}
