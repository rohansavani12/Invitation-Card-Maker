package com.invitationcardmaker.edigitalcard.pojoClass;

import java.util.ArrayList;

/* loaded from: classes2.dex */
public class PosterBG {
    ArrayList<MainBG> thumbnail_bg;

    public ArrayList<MainBG> getThumbnail_bg() {
        return this.thumbnail_bg;
    }

    public void setThumbnail_bg(ArrayList<MainBG> arrayList) {
        this.thumbnail_bg = arrayList;
    }
}
