package com.invitationcardmaker.edigitalcard.pojoClass;

/* loaded from: classes2.dex */
public class PosterKey {
    private String key;

    public String getKey() {
        return this.key;
    }

    public void setKey(String str) {
        this.key = str;
    }

    public String toString() {
        return "ClassPojo [key = " + this.key + "]";
    }
}
