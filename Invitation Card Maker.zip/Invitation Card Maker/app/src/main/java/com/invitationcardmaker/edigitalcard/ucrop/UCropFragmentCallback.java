package com.invitationcardmaker.edigitalcard.ucrop;

/* loaded from: classes2.dex */
public interface UCropFragmentCallback {
    void loadingProgress(boolean z);

    void onCropFinish(UCropFragment.UCropResult uCropResult);
}
