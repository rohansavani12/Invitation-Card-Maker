package com.invitationcardmaker.edigitalcard.ucrop.callback;

import android.net.Uri;

/* loaded from: classes2.dex */
public interface BitmapCropCallback {
    void onBitmapCropped(Uri uri, int i, int i2, int i3, int i4);

    void onCropFailure(Throwable th);
}
