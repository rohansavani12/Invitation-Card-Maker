package com.invitationcardmaker.edigitalcard.ucrop.callback;

import android.graphics.Bitmap;
import com.invitationcardmaker.edigitalcard.ucrop.model.ExifInfo;

/* loaded from: classes2.dex */
public interface BitmapLoadCallback {
    void onBitmapLoaded(Bitmap bitmap, ExifInfo exifInfo, String str, String str2);

    void onFailure(Exception exc);
}
