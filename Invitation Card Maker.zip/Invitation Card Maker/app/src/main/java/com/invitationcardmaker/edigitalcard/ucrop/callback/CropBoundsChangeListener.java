package com.invitationcardmaker.edigitalcard.ucrop.callback;

/* loaded from: classes2.dex */
public interface CropBoundsChangeListener {
    void onCropAspectRatioChanged(float f);
}
