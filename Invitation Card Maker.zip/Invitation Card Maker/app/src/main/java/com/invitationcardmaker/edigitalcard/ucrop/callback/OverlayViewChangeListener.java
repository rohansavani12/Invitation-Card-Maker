package com.invitationcardmaker.edigitalcard.ucrop.callback;

import android.graphics.RectF;

/* loaded from: classes2.dex */
public interface OverlayViewChangeListener {
    void onCropRectUpdated(RectF rectF);
}
