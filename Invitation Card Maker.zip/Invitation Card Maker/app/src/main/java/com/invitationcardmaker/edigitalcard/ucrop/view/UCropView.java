package com.invitationcardmaker.edigitalcard.ucrop.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.ucrop.callback.CropBoundsChangeListener;
import com.invitationcardmaker.edigitalcard.ucrop.callback.OverlayViewChangeListener;

public class UCropView extends FrameLayout {
    public static final int[] ucrop_UCropView = {R.attr.ucrop_aspect_ratio_x, R.attr.ucrop_aspect_ratio_y, R.attr.ucrop_circle_dimmed_layer, R.attr.ucrop_dimmed_color, R.attr.ucrop_frame_color, R.attr.ucrop_frame_stroke_size, R.attr.ucrop_grid_color, R.attr.ucrop_grid_column_count, R.attr.ucrop_grid_row_count, R.attr.ucrop_grid_stroke_size, R.attr.ucrop_show_frame, R.attr.ucrop_show_grid, R.attr.ucrop_show_oval_crop_frame};
    public GestureCropImageView mGestureCropImageView;
    public final OverlayView mViewOverlay;

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public UCropView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public UCropView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        LayoutInflater.from(context).inflate(R.layout.ucrop_view, (ViewGroup) this, true);
        this.mGestureCropImageView = (GestureCropImageView) findViewById(R.id.image_view_crop);
        OverlayView overlayView = (OverlayView) findViewById(R.id.view_overlay);
        this.mViewOverlay = overlayView;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ucrop_UCropView);
        overlayView.processStyledAttributes(obtainStyledAttributes);
        this.mGestureCropImageView.processStyledAttributes(obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        setListenersToViews();
    }

    private void setListenersToViews() {
        this.mGestureCropImageView.setCropBoundsChangeListener(new CropBoundsChangeListener() {
            /* class com.invitationcardmaker.edigitalcard.ucrop.view.UCropView.AnonymousClass1 */

            @Override // com.invitationcardmaker.edigitalcard.ucrop.callback.CropBoundsChangeListener
            public void onCropAspectRatioChanged(float f) {
                UCropView.this.mViewOverlay.setTargetAspectRatio(f);
            }
        });
        this.mViewOverlay.setOverlayViewChangeListener(new OverlayViewChangeListener() {
            /* class com.invitationcardmaker.edigitalcard.ucrop.view.UCropView.AnonymousClass2 */

            @Override // com.invitationcardmaker.edigitalcard.ucrop.callback.OverlayViewChangeListener
            public void onCropRectUpdated(RectF rectF) {
                UCropView.this.mGestureCropImageView.setCropRect(rectF);
            }
        });
    }

    public GestureCropImageView getCropImageView() {
        return this.mGestureCropImageView;
    }

    public OverlayView getOverlayView() {
        return this.mViewOverlay;
    }

    public void resetCropImageView() {
        removeView(this.mGestureCropImageView);
        this.mGestureCropImageView = new GestureCropImageView(getContext());
        setListenersToViews();
        this.mGestureCropImageView.setCropRect(getOverlayView().getCropViewRect());
        addView(this.mGestureCropImageView, 0);
    }
}