package com.invitationcardmaker.edigitalcard.view;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.core.view.ViewCompat;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.invitationcardmaker.edigitalcard.R;
import com.invitationcardmaker.edigitalcard.listener.MultiTouchListener;
import com.invitationcardmaker.edigitalcard.utility.ImageUtils;
import com.invitationcardmaker.edigitalcard.utils.ElementInfo;
import cz.msebera.android.httpclient.HttpStatus;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class StickerView extends RelativeLayout implements MultiTouchListener.TouchCallbackListener {
    public static final String TAG = "ResizableStickerView";
    double angle = 0.0d;
    int baseh;
    int basew;
    int basex;
    int basey;
    private ImageView border_iv;
    private Bitmap btmp = null;
    private String colorType = "colored";
    private Context context;
    public int currentState = 0;
    double dAngle = 0.0d;
    private ImageView delete_iv;
    private String drawableId;
    float f244cX = 0.0f;
    float f245cY = 0.0f;
    public int f246he;
    public int f247wi;
    public int f26s;
    private String field_four = "";
    private int field_one = 0;
    private String field_three = "";
    public String field_two = "0,0";
    private ImageView flip_iv;
    float heightMain = 0.0f;
    private int hueProg = 1;
    private int imgAlpha = 255;
    private int imgColor = 0;
    private boolean isBorderVisible = false;
    private boolean isColorFilterEnable = false;
    public boolean isMultiTouchEnabled = true;
    public boolean isUndoRedo = false;
    public int leftMargin = 0;
    public TouchEventListener listener = null;
    private View.OnTouchListener mTouchListener1 = new TouchListerner();
    public ImageView main_iv;
    int margl;
    int margt;
    private View.OnTouchListener rTouchListener = new TouchListner1();
    private Uri resUri = null;
    private ImageView rotate_iv;
    private float rotation;
    Animation scale;
    private int scaleRotateProg = 0;
    private ImageView scale_iv;
    int screenHeight = HttpStatus.SC_MULTIPLE_CHOICES;
    int screenWidth = HttpStatus.SC_MULTIPLE_CHOICES;
    public String stkr_path = "";
    double tAngle = 0.0d;
    public int topMargin = 0;
    double vAngle = 0.0d;
    float widthMain = 0.0f;
    private int xRotateProg = 0;
    private int yRotateProg = 0;
    private float yRotation;
    private int zRotateProg = 0;
    Animation zoomInScale;
    Animation zoomOutScale;

    public interface TouchEventListener {
        void onDelete();

        void onEdit(View view, Uri uri);

        void onRotateDown(View view);

        void onRotateMove(View view);

        void onRotateUp(View view);

        void onScaleDown(View view);

        void onScaleMove(View view);

        void onScaleUp(View view);

        void onTouchDown(View view);

        void onTouchMove(View view);

        void onTouchMoveUpClick(View view);

        void onTouchUp(View view);
    }

    public StickerView(Context context2) {
        super(context2);
        init(context2);
    }

    public StickerView(Context context2, boolean z) {
        super(context2);
        this.isUndoRedo = z;
        init(context2);
    }

    public StickerView(Context context2, AttributeSet attributeSet) {
        super(context2, attributeSet);
        init(context2);
    }

    public StickerView(Context context2, AttributeSet attributeSet, int i) {
        super(context2, attributeSet, i);
        init(context2);
    }

    public StickerView setOnTouchCallbackListener(TouchEventListener touchEventListener) {
        this.listener = touchEventListener;
        return this;
    }

    public void init(Context context2) {
        this.context = context2;
        this.main_iv = new ImageView(this.context);
        this.scale_iv = new ImageView(this.context);
        this.border_iv = new ImageView(this.context);
        this.flip_iv = new ImageView(this.context);
        this.rotate_iv = new ImageView(this.context);
        this.delete_iv = new ImageView(this.context);
        this.f26s = dpToPx(this.context, 25);
        this.f247wi = dpToPx(this.context, 200);
        this.f246he = dpToPx(this.context, 200);
        this.scale_iv.setImageResource(R.drawable.unitech_sticker_scale);
        this.border_iv.setImageResource(R.drawable.unitech_sticker_border_gray);
        this.flip_iv.setImageResource(R.drawable.unitech_sticker_flip);
        this.rotate_iv.setImageResource(R.drawable.unitech_sticker_rotate);
        this.delete_iv.setImageResource(R.drawable.unitech_sticker_delete1);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(this.f247wi, this.f246he);
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams2.setMargins(5, 5, 5, 5);
        if (Build.VERSION.SDK_INT >= 17) {
            layoutParams2.addRule(17);
        } else {
            layoutParams2.addRule(1);
        }
        int i = this.f26s;
        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(i, i);
        layoutParams3.addRule(12);
        layoutParams3.addRule(11);
        layoutParams3.setMargins(5, 5, 5, 5);
        int i2 = this.f26s;
        RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams(i2, i2);
        layoutParams4.addRule(10);
        layoutParams4.addRule(11);
        layoutParams4.setMargins(5, 5, 5, 5);
        int i3 = this.f26s;
        RelativeLayout.LayoutParams layoutParams5 = new RelativeLayout.LayoutParams(i3, i3);
        layoutParams5.addRule(12);
        layoutParams5.addRule(9);
        layoutParams5.setMargins(5, 5, 5, 5);
        int i4 = this.f26s;
        RelativeLayout.LayoutParams layoutParams6 = new RelativeLayout.LayoutParams(i4, i4);
        layoutParams6.addRule(10);
        layoutParams6.addRule(9);
        layoutParams6.setMargins(5, 5, 5, 5);
        RelativeLayout.LayoutParams layoutParams7 = new RelativeLayout.LayoutParams(-1, -1);
        setLayoutParams(layoutParams);
        setBackgroundResource(R.drawable.sticker_gray1);
        addView(this.border_iv);
        this.border_iv.setLayoutParams(layoutParams7);
        this.border_iv.setScaleType(ImageView.ScaleType.FIT_XY);
        this.border_iv.setTag("border_iv");
        addView(this.main_iv);
        this.main_iv.setLayoutParams(layoutParams2);
        addView(this.flip_iv);
        this.flip_iv.setLayoutParams(layoutParams4);
        this.flip_iv.setOnClickListener(new View.OnClickListener() {
            /* class com.invitationcardmaker.edigitalcard.view.StickerView.AnonymousClass1 */

            public void onClick(View view) {
                ImageView imageView = StickerView.this.main_iv;
                float f = -180.0f;
                if (StickerView.this.main_iv.getRotationY() == -180.0f) {
                    f = 0.0f;
                }
                imageView.setRotationY(f);
                StickerView.this.main_iv.invalidate();
                StickerView.this.requestLayout();
                StickerView.this.clickToSaveWork();
            }
        });
        addView(this.rotate_iv);
        this.rotate_iv.setLayoutParams(layoutParams5);
        this.rotate_iv.setOnTouchListener(this.rTouchListener);
        addView(this.delete_iv);
        this.delete_iv.setLayoutParams(layoutParams6);
        this.delete_iv.setOnClickListener(new DeleteClick());
        addView(this.scale_iv);
        this.scale_iv.setLayoutParams(layoutParams3);
        this.scale_iv.setOnTouchListener(this.mTouchListener1);
        this.scale_iv.setTag("scale_iv");
        this.rotation = getRotation();
        this.scale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_anim_view);
        this.zoomOutScale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_zoom_out_view);
        this.zoomInScale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_zoom_in_view);
        this.isMultiTouchEnabled = setDefaultTouchListener(true);
    }

    public boolean setDefaultTouchListener(boolean z) {
        if (z) {
            setOnTouchListener(new MultiTouchListener().enableRotation(true).setOnTouchCallbackListener(this));
            return true;
        }
        setOnTouchListener(null);
        return false;
    }

    public void setBorderVisibility(boolean z) {
        this.isBorderVisible = z;
        if (!z) {
            this.border_iv.setVisibility(8);
            this.scale_iv.setVisibility(8);
            this.flip_iv.setVisibility(8);
            this.rotate_iv.setVisibility(8);
            this.delete_iv.setVisibility(8);
            setBackgroundResource(0);
            if (this.isColorFilterEnable) {
                this.main_iv.setColorFilter(Color.parseColor("#303828"));
            }
        } else if (this.border_iv.getVisibility() != 0) {
            this.border_iv.setVisibility(0);
            this.scale_iv.setVisibility(0);
            this.flip_iv.setVisibility(0);
            this.rotate_iv.setVisibility(0);
            this.delete_iv.setVisibility(0);
            setBackgroundResource(R.drawable.sticker_gray1);
            this.main_iv.startAnimation(this.scale);
        }
    }

    public boolean getBorderVisbilty() {
        return this.isBorderVisible;
    }

    public void opecitySticker(int i) {
        try {
            this.main_iv.setAlpha(i);
            this.imgAlpha = i;
        } catch (Exception unused) {
        }
    }

    public int getHueProg() {
        return this.hueProg;
    }

    public void setHueProg(int i) {
        this.hueProg = i;
        if (i == 0) {
            this.main_iv.setColorFilter(-1);
        } else if (i == 100) {
            this.main_iv.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
        } else {
            this.main_iv.setColorFilter(ColorFilterGenerator.adjustHue((float) i));
        }
    }

    public String getColorType() {
        return this.colorType;
    }

    public int getAlphaProg() {
        return this.imgAlpha;
    }

    public void setAlphaProg(int i) {
        opecitySticker(i);
    }

    public int getColor() {
        return this.imgColor;
    }

    public void setColor(int i) {
        try {
            this.main_iv.setColorFilter(i);
            this.imgColor = i;
        } catch (Exception unused) {
        }
    }

    public void setBgDrawable(String str) {
        Glide.with(this.context).load(Integer.valueOf(getResources().getIdentifier(str, "drawable", this.context.getPackageName()))).apply(((RequestOptions) ((RequestOptions) new RequestOptions().dontAnimate()).placeholder(R.drawable.no_image)).error(R.drawable.no_image)).into(this.main_iv);
        this.drawableId = str;
        if (!this.isUndoRedo) {
            this.main_iv.startAnimation(this.zoomOutScale);
        }
    }

    public void setStrPath(String str) {
        try {
            ImageView imageView = this.main_iv;
            Uri parse = Uri.parse(str);
            Context context2 = this.context;
            int i = this.screenWidth;
            int i2 = this.screenHeight;
            if (i <= i2) {
                i = i2;
            }
            imageView.setImageBitmap(ImageUtils.getResampleImageBitmap(parse, context2, i));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.stkr_path = str;
        if (!this.isUndoRedo) {
            this.main_iv.startAnimation(this.zoomOutScale);
        }
    }

    public Uri getMainImageUri() {
        return this.resUri;
    }

    public void setMainImageUri(Uri uri) {
        this.resUri = uri;
        this.main_iv.setImageURI(uri);
    }

    public Bitmap getMainImageBitmap() {
        return this.btmp;
    }

    public void setMainImageBitmap(Bitmap bitmap) {
        this.main_iv.setImageBitmap(bitmap);
    }

    public void optimize(float f, float f2) {
        setX(getX() * f);
        setY(getY() * f2);
        getLayoutParams().width = (int) (((float) this.f247wi) * f);
        getLayoutParams().height = (int) (((float) this.f246he) * f2);
    }

    public void optimizeScreen(float f, float f2) {
        this.screenHeight = (int) f2;
        this.screenWidth = (int) f;
    }

    public void setMainLayoutWH(float f, float f2) {
        this.widthMain = f;
        this.heightMain = f2;
    }

    public float getMainWidth() {
        return this.widthMain;
    }

    public float getMainHeight() {
        return this.heightMain;
    }

    public void incrX() {
        setX(getX() + 2.0f);
    }

    public void decX() {
        setX(getX() - 2.0f);
    }

    public void incrY() {
        setY(getY() + 2.0f);
    }

    public void decY() {
        setY(getY() - 2.0f);
    }

    public ElementInfo getComponentInfo() {
        Bitmap bitmap = this.btmp;
        if (bitmap != null) {
            this.stkr_path = saveBitmapObject1(bitmap);
        }
        ElementInfo elementInfo = new ElementInfo();
        elementInfo.setPOS_X(getX());
        elementInfo.setPOS_Y(getY());
        elementInfo.setWIDTH(this.f247wi);
        elementInfo.setHEIGHT(this.f246he);
        elementInfo.setRES_ID(this.drawableId);
        elementInfo.setSTC_COLOR(this.imgColor);
        elementInfo.setRES_URI(this.resUri);
        elementInfo.setSTC_OPACITY(this.imgAlpha);
        elementInfo.setCOLORTYPE(this.colorType);
        elementInfo.setBITMAP(this.btmp);
        elementInfo.setROTATION(getRotation());
        elementInfo.setY_ROTATION(this.main_iv.getRotationY());
        elementInfo.setXRotateProg(this.xRotateProg);
        elementInfo.setYRotateProg(this.yRotateProg);
        elementInfo.setZRotateProg(this.zRotateProg);
        elementInfo.setScaleProg(this.scaleRotateProg);
        elementInfo.setSTKR_PATH(this.stkr_path);
        elementInfo.setSTC_HUE(this.hueProg);
        elementInfo.setFIELD_ONE(this.field_one);
        elementInfo.setFIELD_TWO(this.field_two);
        elementInfo.setFIELD_THREE(this.field_three);
        elementInfo.setFIELD_FOUR(this.field_four);
        return elementInfo;
    }

    public ElementInfo getComponentInfoUL() {
        ElementInfo elementInfo = new ElementInfo();
        elementInfo.setPOS_X(getX());
        elementInfo.setPOS_Y(getY());
        elementInfo.setWIDTH(this.f247wi);
        elementInfo.setHEIGHT(this.f246he);
        elementInfo.setRES_ID(this.drawableId);
        elementInfo.setSTC_COLOR(this.imgColor);
        elementInfo.setRES_URI(this.resUri);
        elementInfo.setSTC_OPACITY(this.imgAlpha);
        elementInfo.setCOLORTYPE(this.colorType);
        elementInfo.setBITMAP(this.btmp);
        elementInfo.setROTATION(getRotation());
        elementInfo.setY_ROTATION(this.main_iv.getRotationY());
        elementInfo.setXRotateProg(this.xRotateProg);
        elementInfo.setYRotateProg(this.yRotateProg);
        elementInfo.setZRotateProg(this.zRotateProg);
        elementInfo.setScaleProg(this.scaleRotateProg);
        elementInfo.setSTKR_PATH(this.stkr_path);
        elementInfo.setSTC_HUE(this.hueProg);
        elementInfo.setFIELD_ONE(this.field_one);
        elementInfo.setFIELD_TWO(this.field_two);
        elementInfo.setFIELD_THREE(this.field_three);
        elementInfo.setFIELD_FOUR(this.field_four);
        return elementInfo;
    }

    public void setComponentInfo(ElementInfo elementInfo) {
        this.f247wi = elementInfo.getWIDTH();
        this.f246he = elementInfo.getHEIGHT();
        this.drawableId = elementInfo.getRES_ID();
        this.resUri = elementInfo.getRES_URI();
        this.btmp = elementInfo.getBITMAP();
        this.rotation = elementInfo.getROTATION();
        this.imgColor = elementInfo.getSTC_COLOR();
        this.yRotation = elementInfo.getY_ROTATION();
        this.imgAlpha = elementInfo.getSTC_OPACITY();
        this.stkr_path = elementInfo.getSTKR_PATH();
        this.colorType = elementInfo.getCOLORTYPE();
        this.hueProg = elementInfo.getSTC_HUE();
        this.field_two = elementInfo.getFIELD_TWO();
        if (!this.stkr_path.equals("")) {
            setStrPath(this.stkr_path);
        } else if (this.drawableId.equals("")) {
            this.main_iv.setImageBitmap(this.btmp);
        } else {
            setBgDrawable(this.drawableId);
        }
        if (this.colorType.equals("white")) {
            setColor(this.imgColor);
        } else {
            setHueProg(this.hueProg);
        }
        setRotation(this.rotation);
        opecitySticker(this.imgAlpha);
        if (this.field_two.equals("")) {
            getLayoutParams().width = this.f247wi;
            getLayoutParams().height = this.f246he;
            setX(elementInfo.getPOS_X());
            setY(elementInfo.getPOS_Y());
        } else {
            String[] split = this.field_two.split(",");
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            ((RelativeLayout.LayoutParams) getLayoutParams()).leftMargin = parseInt;
            ((RelativeLayout.LayoutParams) getLayoutParams()).topMargin = parseInt2;
            getLayoutParams().width = this.f247wi;
            getLayoutParams().height = this.f246he;
            setX(elementInfo.getPOS_X() + ((float) (parseInt * -1)));
            setY(elementInfo.getPOS_Y() + ((float) (parseInt2 * -1)));
        }
        if (elementInfo.getTYPE() == "SHAPE") {
            this.flip_iv.setVisibility(8);
        }
        if (elementInfo.getTYPE() == "STICKER") {
            this.flip_iv.setVisibility(0);
        }
        this.main_iv.setRotationY(this.yRotation);
    }

    private void saveStkrBitmap(final Bitmap bitmap) {
        final ProgressDialog show = ProgressDialog.show(this.context, "", "", true);
        show.setCancelable(false);
        new Thread(new Runnable() {
            /* class com.invitationcardmaker.edigitalcard.view.StickerView.AnonymousClass2 */

            public void run() {
                try {
                    StickerView stickerView = StickerView.this;
                    stickerView.stkr_path = stickerView.saveBitmapObject1(bitmap);
                } catch (Exception e) {
                    Log.i("testing", "Exception " + e.getMessage());
                    e.printStackTrace();
                } catch (Throwable unused) {
                }
                show.dismiss();
            }
        }).start();
        show.setOnDismissListener(new RingProgressClick());
    }

    public String saveBitmapObject1(Bitmap bitmap) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), ".Invitation Card Stickers/category1");
        file.mkdirs();
        File file2 = new File(file, "raw1-" + System.currentTimeMillis() + ".png");
        String absolutePath = file2.getAbsolutePath();
        if (file2.exists()) {
            file2.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.close();
            return absolutePath;
        } catch (Exception e) {
            e.printStackTrace();
            Log.i("testing", "Exception" + e.getMessage());
            return "";
        }
    }

    public int dpToPx(Context context2, int i) {
        context2.getResources();
        return (int) (Resources.getSystem().getDisplayMetrics().density * ((float) i));
    }

    private double getLength(double d, double d2, double d3, double d4) {
        return Math.sqrt(Math.pow(d4 - d2, 2.0d) + Math.pow(d3 - d, 2.0d));
    }

    public void enableColorFilter(boolean z) {
        this.isColorFilterEnable = z;
    }

    @Override // com.invitationcardmaker.edigitalcard.listener.MultiTouchListener.TouchCallbackListener
    public void onTouchCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchDown(view);
        }
    }

    @Override // com.invitationcardmaker.edigitalcard.listener.MultiTouchListener.TouchCallbackListener
    public void onTouchUpCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchUp(view);
        }
    }

    @Override // com.invitationcardmaker.edigitalcard.listener.MultiTouchListener.TouchCallbackListener
    public void onTouchUpClick(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchMoveUpClick(view);
        }
    }

    @Override // com.invitationcardmaker.edigitalcard.listener.MultiTouchListener.TouchCallbackListener
    public void onTouchMoveCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchMove(view);
        }
    }

    class TouchListerner implements View.OnTouchListener {
        TouchListerner() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            StickerView stickerView = (StickerView) view.getParent();
            int rawX = (int) motionEvent.getRawX();
            int rawY = (int) motionEvent.getRawY();
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) StickerView.this.getLayoutParams();
            int action = motionEvent.getAction();
            if (action == 0) {
                if (stickerView != null) {
                    stickerView.requestDisallowInterceptTouchEvent(true);
                }
                if (StickerView.this.listener != null) {
                    StickerView.this.listener.onScaleDown(StickerView.this);
                }
                StickerView.this.invalidate();
                StickerView.this.basex = rawX;
                StickerView.this.basey = rawY;
                StickerView stickerView2 = StickerView.this;
                stickerView2.basew = stickerView2.getWidth();
                StickerView stickerView3 = StickerView.this;
                stickerView3.baseh = stickerView3.getHeight();
                StickerView.this.getLocationOnScreen(new int[2]);
                StickerView.this.margl = layoutParams.leftMargin;
                StickerView.this.margt = layoutParams.topMargin;
                StickerView.this.currentState = 1;
            } else if (action == 1) {
                StickerView stickerView4 = StickerView.this;
                stickerView4.f247wi = stickerView4.getLayoutParams().width;
                StickerView stickerView5 = StickerView.this;
                stickerView5.f246he = stickerView5.getLayoutParams().height;
                StickerView stickerView6 = StickerView.this;
                stickerView6.leftMargin = ((RelativeLayout.LayoutParams) stickerView6.getLayoutParams()).leftMargin;
                StickerView stickerView7 = StickerView.this;
                stickerView7.topMargin = ((RelativeLayout.LayoutParams) stickerView7.getLayoutParams()).topMargin;
                StickerView stickerView8 = StickerView.this;
                stickerView8.field_two = String.valueOf(StickerView.this.leftMargin) + "," + String.valueOf(StickerView.this.topMargin);
                if (StickerView.this.listener != null) {
                    StickerView.this.listener.onScaleUp(StickerView.this);
                    if (StickerView.this.currentState == 3) {
                        StickerView.this.clickToSaveWork();
                    }
                    StickerView.this.currentState = 2;
                }
            } else if (action == 2) {
                if (stickerView != null) {
                    stickerView.requestDisallowInterceptTouchEvent(true);
                }
                if (StickerView.this.listener != null) {
                    StickerView.this.listener.onScaleMove(StickerView.this);
                }
                float degrees = (float) Math.toDegrees(Math.atan2((double) (rawY - StickerView.this.basey), (double) (rawX - StickerView.this.basex)));
                if (degrees < 0.0f) {
                    degrees += 360.0f;
                }
                int i = rawX - StickerView.this.basex;
                int i2 = rawY - StickerView.this.basey;
                int i3 = i2 * i2;
                int sqrt = (int) (Math.sqrt((double) ((i * i) + i3)) * Math.cos(Math.toRadians((double) (degrees - StickerView.this.getRotation()))));
                int sqrt2 = (int) (Math.sqrt((double) ((sqrt * sqrt) + i3)) * Math.sin(Math.toRadians((double) (degrees - StickerView.this.getRotation()))));
                int i4 = (sqrt * 2) + StickerView.this.basew;
                int i5 = (sqrt2 * 2) + StickerView.this.baseh;
                if (i4 > StickerView.this.f26s) {
                    layoutParams.width = i4;
                    layoutParams.leftMargin = StickerView.this.margl - sqrt;
                }
                if (i5 > StickerView.this.f26s) {
                    layoutParams.height = i5;
                    layoutParams.topMargin = StickerView.this.margt - sqrt2;
                }
                StickerView.this.setLayoutParams(layoutParams);
                StickerView.this.performLongClick();
                StickerView.this.currentState = 3;
            }
            return true;
        }
    }

    class TouchListner1 implements View.OnTouchListener {
        TouchListner1() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            StickerView stickerView = (StickerView) view.getParent();
            int action = motionEvent.getAction();
            if (action == 0) {
                if (stickerView != null) {
                    stickerView.requestDisallowInterceptTouchEvent(true);
                }
                if (StickerView.this.listener != null) {
                    StickerView.this.listener.onRotateDown(StickerView.this);
                }
                Rect rect = new Rect();
                ((View) view.getParent()).getGlobalVisibleRect(rect);
                StickerView.this.f244cX = rect.exactCenterX();
                StickerView.this.f245cY = rect.exactCenterY();
                StickerView.this.vAngle = (double) ((View) view.getParent()).getRotation();
                StickerView stickerView2 = StickerView.this;
                stickerView2.tAngle = (Math.atan2((double) (stickerView2.f245cY - motionEvent.getRawY()), (double) (StickerView.this.f244cX - motionEvent.getRawX())) * 180.0d) / 3.141592653589793d;
                StickerView stickerView3 = StickerView.this;
                stickerView3.dAngle = stickerView3.vAngle - StickerView.this.tAngle;
                StickerView.this.currentState = 1;
            } else if (action != 1) {
                if (action == 2) {
                    if (stickerView != null) {
                        stickerView.requestDisallowInterceptTouchEvent(true);
                    }
                    if (StickerView.this.listener != null) {
                        StickerView.this.listener.onRotateMove(StickerView.this);
                    }
                    StickerView stickerView4 = StickerView.this;
                    stickerView4.angle = (Math.atan2((double) (stickerView4.f245cY - motionEvent.getRawY()), (double) (StickerView.this.f244cX - motionEvent.getRawX())) * 180.0d) / 3.141592653589793d;
                    ((View) view.getParent()).setRotation((float) (StickerView.this.angle + StickerView.this.dAngle));
                    ((View) view.getParent()).invalidate();
                    ((View) view.getParent()).requestLayout();
                    StickerView.this.currentState = 3;
                }
            } else if (StickerView.this.listener != null) {
                StickerView.this.listener.onRotateUp(StickerView.this);
                if (StickerView.this.currentState == 3) {
                    StickerView.this.clickToSaveWork();
                }
                StickerView.this.currentState = 2;
            }
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public class DeleteClick implements View.OnClickListener {
        DeleteClick() {
        }

        public void onClick(View view) {
            final ViewGroup viewGroup = (ViewGroup) StickerView.this.getParent();
            StickerView.this.zoomInScale.setAnimationListener(new Animation.AnimationListener() {
                /* class com.invitationcardmaker.edigitalcard.view.StickerView.DeleteClick.AnonymousClass1 */

                public void onAnimationRepeat(Animation animation) {
                }

                public void onAnimationStart(Animation animation) {
                }

                public void onAnimationEnd(Animation animation) {
                    viewGroup.removeView(StickerView.this);
                }
            });
            StickerView.this.main_iv.startAnimation(StickerView.this.zoomInScale);
            StickerView.this.setBorderVisibility(false);
            if (StickerView.this.listener != null) {
                StickerView.this.listener.onDelete();
            }
        }
    }

    class RingProgressClick implements DialogInterface.OnDismissListener {
        public void onDismiss(DialogInterface dialogInterface) {
        }

        RingProgressClick() {
        }
    }

    public void clickToSaveWork() {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchMoveUpClick(this);
        }
    }
}